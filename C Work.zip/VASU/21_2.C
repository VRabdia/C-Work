#include<stdio.h>
#include<conio.h>
struct var
{
	int q;
};
void main()
{
	struct var a[100];
	int i,n,temp;
	clrscr();
	printf("Enter Size Of Data:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("a[%d] = ",i);
		scanf("%d",&a[i].q);
	}
	clrscr();
	for(i=0;i<n;i++)
	{
		printf("a[%d] = %d\n",i,a[i].q);
	}
	printf("\nWhat Would You Like To Search For:");
	scanf("%d",&temp);
	clrscr();
	for(i=0;i<n;i++)
	{
		if(a[i].q==temp)
		{
			printf("a[%d] = %d\n",i,a[i].q);
		}
	}
	getch();
}