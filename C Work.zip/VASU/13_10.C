#include<stdio.h>
#include<conio.h>
void main()
{
	int a[100],cnt,s,i,n;
	clrscr();
	printf("Enter size Of Data:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("A[%d] = ",i);
		scanf("%d",&a[i]);
	}
	printf("What Would You Like To Search For:");
	scanf("%d",&s);
	for(i=0,cnt=0;i<n;i++)
	{
		if(a[i]==s)
		{
			cnt++;
		}
	}
	printf("%d is repeated %d times in Data",s,cnt);
	getch();
}