#include<stdio.h>
#include<conio.h>
#include"19_1_2.h"
void main()
{
	int ch,s;
	clrscr();
	sc:
	printf("1:SUM");
	printf("\n2:SUB");
	printf("\n3:MUL");
	printf("\n4:DIV");
	printf("\n\nEnter Choice:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:
		{
			s=sum();
			printf("\nSum = %d",s);
			break;
		}
		case 2:
		{
			s=sub();
			printf("\nSub = %d",s);
			break;
		}
		case 3:
		{
			s=mul();
			printf("\nMul = %d",s);
			break;
		}
		case 4:
		{
			s=div();
			printf("\nDiv = %d",s);
			break;
		}
		default:
		{
			clrscr();
			printf("INVALID CHOICE..!!\n\n");
			goto sc;
		}
	}
	getch();
	}