#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,k,l;
	clrscr();
	for(i=1,l=10;i<=5;i++)
	{
		for(k=1;k<=5-i;k++)
		{
			printf(" ");
		}
		for(j=l;j<=10;j++)
		{
			printf("*");
		}
		l=l-2;
		printf("\n");
	}
	getch();
}