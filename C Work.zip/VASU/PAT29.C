#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,k,l;
	clrscr();
	for(i=1,k=1,l=17;i<=9;i++)
	{
		for(j=1;j<=17;j++)
		{
			if(j%2!=0 && (i==1 || i==5 || i==9 || j==1 || j==9 || j==17))
			{
				printf("*");
			}
			else if(k==j || l==j)
			{
				printf("*");
			}
			else
			{
				printf(" ");
			}
		}
		k=k+2;
		l=l-2;
		printf("\n");
	}
	getch();
}