#include<stdio.h>
#include<conio.h>
void main()
{
	int a[100][100],i,j,r,c,csum,rsum;
	clrscr();
	printf("Enter Number Of Rows:");
	scanf("%d",&r);
	printf("Enter Number Of Columns:");
	scanf("%d",&c);
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			printf("Enter a[%d][%d]:",i,j);
			scanf("%d",&a[i][j]);
		}
	}
	printf("\n");
	for(i=0;i<r;i++)
	{
		for(j=0,rsum=0;j<c;j++)
		{
			printf("\t%d",a[i][j]);
			rsum=rsum+a[i][j];
		}
		printf("\t=%d",rsum);
		printf("\n\n");
	}
	for(j=0;j<c;j++)
	{
		for(i=0,csum=0;i<r;i++)
		{
			csum=csum+a[i][j];
		}
		printf("\t=%d",csum);
	}
	getch();
}