#include<stdio.h>
#include<conio.h>
void max(int a,int b,int c)
{
	int max;
	if(a>b && a>c)
	{
		max=a;
	}
	else if(b>a && b>c)
	{
		max=b;
	}
	else if(c>a && c>b)
	{
		max=c;
	}
	printf("\n\nMax = %d",max);
}
void main()
{
	int a,b,c;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);
	printf("Enter c:");
	scanf("%d",&c);
	max(a,b,c);
	getch();
}