#include<stdio.h>
#include<conio.h>
void main()
{
	int a=0,b=1,sum,n;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	do
	{
		sum=a+b;
		printf("%d\t",a);
		a=b;
		b=sum;
	}while(a<=n);
	getch();
}