#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,n;
	char s[100][100],s1[100];
	clrscr();
	printf("Enter Number Of Total Names:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Enter Name:");
		scanf("%s",&s[i]);
	}
	for(i=0;i<=n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(strcmp(s[i],s[j])>0)
			{
				strcpy(s1,s[i]);
				strcpy(s[i],s[j]);
				strcpy(s[j],s1);
			}
		}
	}
	printf("\nSort Order = ");
	for(i=0;i<n;i++)
	{
		printf("\n%s",s[i]);
	}
	getch();
}