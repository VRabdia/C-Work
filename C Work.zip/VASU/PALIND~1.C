#include<stdio.h>
#include<conio.h>
void main()
{
	int n,r,rev=0,a;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	a=n;
	while(n>0)
	{
		r=n%10;
		rev=(rev*10)+r;
		n=n/10;
	}
	if(a==rev)
	{
		printf("\n%d is a palindromic number",a);
	}
	else
	{
		printf("\n%d is not a palindromic number",a);
	}
	getch();
}