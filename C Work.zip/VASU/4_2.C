#include<stdio.h>
#include<conio.h>
void main()
{
	int side,area;
	clrscr();
	printf("Enter the Side of the Square: ");
	scanf("%d",&side);
	area=side*side;
	printf("\nThe Area of the Square is: %d",area);
	getch();
}