#include<stdio.h>
#include<conio.h>
void main()
{
	int n,i=1,sum=0;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	while(i<=n)
	{
		if(n%i==0)
		{
			sum=sum+i;
			i++;
		}
		else
		{
			i++;
		}
	}
	if(sum==(n*2))
	{
		printf("%d is a perfect number",n);
	}
	else
	{
		printf("%d is not a perfect number",n);
	}
	getch();
}