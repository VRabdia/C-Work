#include<stdio.h>
#include<conio.h>
void main()
{
	int a[1][100][100],i,j,k;
	clrscr();
	for(i=0;i<1;i++)
	{
		for(j=0;j<2;j++)
		{
			for(k=0;k<3;k++)
			{
				printf("a[%d][%d][%d]=%d%d%d",i,j,k,i,j,k);
				printf("\t");
			}
			printf("\n");
		}
	}
	getch();
}