#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,sum;
	clrscr();
	for(i=1;i<=10;i++)
	{
		for(j=1,sum=i;j<=5;j++)
		{
			printf("%d\t",sum);
			sum=sum+10;
		}
		printf("\n");
	}
	getch();
}