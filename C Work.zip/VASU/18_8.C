#include<stdio.h>
#include<conio.h>
void main()
{
	char s[100],temp,rep,i;
	clrscr();
	printf("Enter String:");
	gets(s);
	printf("\n");
	for(i=0;s[i]!=0;i++)
	{
		printf("%c",s[i]);
	}
	printf("\n");
	printf("\nWhat Would You Like To Replace:");
	scanf("%c",&temp);
	flushall();
	printf("\nWith What Would You Like To Replace It:");
	scanf("%c",&rep);
	for(i=0;s[i]!=0;i++)
	{
		if(s[i]==temp)
		{
			s[i]=rep;
		}
	}
	printf("\n");
	for(i=0;s[i]!=0;i++)
	{
		printf("%c",s[i]);
	}
	getch();
}