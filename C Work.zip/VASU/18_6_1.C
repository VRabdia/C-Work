#include<stdio.h>
#include<conio.h>
void main()
{
	char s[100],i;
	clrscr();
	printf("Enter String:");
	gets(s);
	if(s[0]>=97 && s[0]<=122)
	{
		s[0]=s[0]-32;
	}
	printf("\n\n");
	for(i=0;s[i]!=0;i++)
	{
		if((s[i]==33 || s[i]==46 || s[i]==63) && s[i+1]==32)
		{
			if(s[i+2]>=97 && s[i+2]<=122)
			{
				s[i+2]=s[i+2]-32;
			}
		}
		printf("%c",s[i]);
	}
	getch();
}