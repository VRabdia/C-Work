#include<stdio.h>
#include<conio.h>
struct var
{
	char n[100];
	int i,s1,s2,s3,s4,s5,total,pr;
};
void main()
{
	struct var fs,sc,th;
	clrscr();
	printf("Enter Name Of Student 1:");
	gets(fs.n);
	printf("Enter Name Of Student 2:");
	gets(sc.n);
	printf("Enter Name Of Student 3:");
	gets(th.n);
	printf("Enter Subject 1 Marks For Student 1:");
	scanf("%d",&fs.s1);
	printf("Enter Subject 2 Marks For Student 1:");
	scanf("%d",&fs.s2);
	printf("Enter Subject 3 Marks For Student 1:");
	scanf("%d",&fs.s3);
	printf("Enter Subject 4 Marks For Student 1:");
	scanf("%d",&fs.s4);
	printf("Enter Subject 5 Marks For Student 1:");
	scanf("%d",&fs.s5);
	printf("Enter Subject 1 Marks For Student 2:");
	scanf("%d",&sc.s1);
	printf("Enter Subject 2 Marks For Student 2:");
	scanf("%d",&sc.s2);
	printf("Enter Subject 3 Marks For Student 2:");
	scanf("%d",&sc.s3);
	printf("Enter Subject 4 Marks For Student 2:");
	scanf("%d",&sc.s4);
	printf("Enter Subject 5 Marks For Student 2:");
	scanf("%d",&sc.s5);
	printf("Enter Subject 1 Marks For Student 3:");
	scanf("%d",&th.s1);
	printf("Enter Subject 2 Marks For Student 3:");
	scanf("%d",&th.s2);
	printf("Enter Subject 3 Marks For Student 3:");
	scanf("%d",&th.s3);
	printf("Enter Subject 4 Marks For Student 3:");
	scanf("%d",&th.s4);
	printf("Enter Subject 5 Marks For Student 3:");
	scanf("%d",&th.s5);
	clrscr();
	fs.total=fs.s1+fs.s2+fs.s3+fs.s4+fs.s5;
	sc.total=sc.s1+sc.s2+sc.s3+sc.s4+sc.s5;
	th.total=th.s1+th.s2+th.s3+th.s4+th.s5;
	fs.pr=fs.total/5;
	sc.pr=sc.total/5;
	th.pr=th.total/5;
	printf("Name\tS1\tS2\tS3\tS4\tS5\tTotal\tPR");
	printf("\n\n");
	for(fs.i=0;fs.n[fs.i]!=0;fs.i++)
	{
		printf("%c",fs.n[fs.i]);
	}
	printf("\t%d\t%d\t%d\t%d\t%d\t%d\t%d",fs.s1,fs.s2,fs.s3,fs.s4,fs.s5,fs.total,fs.pr);
	printf("\n");
	for(sc.i=0;sc.n[sc.i]!=0;sc.i++)
	{
		printf("%c",sc.n[sc.i]);
	}
	printf("\t%d\t%d\t%d\t%d\t%d\t%d\t%d",sc.s1,sc.s2,sc.s3,sc.s4,sc.s5,sc.total,sc.pr);
	printf("\n");
	for(th.i=0;th.n[th.i]!=0;th.i++)
	{
		printf("%c",th.n[th.i]);
	}
	printf("\t%d\t%d\t%d\t%d\t%d\t%d\t%d",th.s1,th.s2,th.s3,th.s4,th.s5,th.total,th.pr);
	getch();
}