#include<stdio.h>
#include<conio.h>
void str()
{
	char s[100],i,n=0;
	printf("Enter String:");
	gets(s);
	for(i=0;s[i]!=0;i++)
	{
		n++;
	}
	printf("\n\n");
	for(i=n-1;i>=0;i--)
	{
		printf("%c",s[i]);
	}
}
void main()
{
	clrscr();
	str();
	getch();
}