#include<stdio.h>
#include<conio.h>
void main()
{
	int a=1,sum=0;
	clrscr();
	do
	{
		if(a%2==0)
		{
			a++;
		}
		else
		{
			sum=sum+a;
			a++;
		}
	}while(a<=10);
	printf("Odd Sum=%d",sum);
	getch();
}