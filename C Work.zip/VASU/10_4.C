#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,n,sum=0;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);
	printf("Enter n:");
	scanf("%d",&n);
	if(a<=b)
	{
		do
		{
			if(a%n==0)
			{
				printf("\n%d",a);
				sum=sum+a;
			}
			else
			{
			}
			a++;
		}while(a<=b);
	}
	else
	{
		do
		{
			if(a%n==0)
			{
				printf("\n%d",a);
				sum=sum+a;
			}
			else
			{
			}
			a--;
		}while(a>=b);
	}
	printf("\nSum=%d",sum);
	getch();
}