#include<stdio.h>
#include<conio.h>
void main()
{
	float c,f;
	clrscr();
	printf("Enter the Temperature in Centigrade: ");
	scanf("%f",&c);
	f=((c*9)/5)+32;
	printf("\nTemperature in Fahrenheit is: %f",f);
	getch();
}