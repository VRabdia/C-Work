#include<stdio.h>
#include<conio.h>
void main()
{
	int a[100],i,n,k,temp;
	clrscr();
	printf("Enter Size Of Data:");
	scanf("%d",&k);
	for(i=0;i<k;i++)
	{
		printf("A[%d] = ",i);
		scanf("%d",&a[i]);
	}
	for(i=0;i<k;i++)
	{
		printf("\nA[%d] = %d",i,a[i]);
	}
	printf("\nOn Which Position Would You Like To Delete The Data:");
	scanf("%d",&temp);
	for(i=0;i<k;i++)
	{
		if(i==temp)
		{
			for(i=temp;i<k;i++)
			{
				a[i]=a[i+1];
			}
		}
	}
	n=k-1;
	printf("\nNEW DATA");
	for(i=0;i<n;i++)
	{
		printf("\nA[%d] = %d",i,a[i]);
	}
	getch();
}