#include<stdio.h>
#include<conio.h>
void main()
{
	int a=1;
	clrscr();
	do
	{
		printf("\n%d",a);
		a++;
	}while(a<=10);
	getch();
}