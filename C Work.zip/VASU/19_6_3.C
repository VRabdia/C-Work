#include<stdio.h>
#include<conio.h>
void disp(char s[])
{
	char r[100],i,cnt;
	for(i=0;s[i]!=0;i++)
	{
		cnt++;
	}
	for(i=cnt;i>=0;i--)
	{

	}
}
void main()
{
	char s[100];
	clrscr();
	printf("Enter String:");
	gets(s);
	disp(s);
	getch();
}