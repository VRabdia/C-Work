#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("\nEnter b:");
	scanf("%d",&b);
	printf("\nEnter c:");
	scanf("%d",&c);
	if(a<10 || b<10 || c<10)
	{
		printf("MULTIMEDIA");
	}
	else
	{
		printf("CREATIVE");
	}
	getch();
}