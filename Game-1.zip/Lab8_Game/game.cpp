#include"maze.hpp"
#include<iostream>

using std::cout; using std::cin; using std::endl;

int main() {
	// srand(time(nullptr)); // random seed
	srand(2); // fixed seed

	RoomPair myRoom[numWalls]; // create a room
	clearWalls(myRoom);
	build(myRoom);

	Room mouseLocation;
	mouseLocation.x = 1;
	mouseLocation.y = 'a';

	Room cheeseRoom;
	cheeseRoom.x = mazeSize;
	cheeseRoom.y = 'a' + mazeSize - 1;

	cout << "Would you like to see the Walls of the Maze? (y)es (n)o: ";
	char userInput;
	cin >> userInput;
	if (userInput == 'y') {
		printMaze(myRoom);
		cout << endl;
	}

	Room exit;
	exit.x = -1;
	exit.y = '*';

	Room nextRoom;

	while (!matchRoom(mouseLocation, cheeseRoom) && !matchRoom(nextRoom, exit)) {
		cout << "The mouse is currently in Room: ";
		printRoom(mouseLocation);
		cout << endl;

		nextRoom = nextMove(mouseLocation);
		RoomPair nextMovePair;
		nextMovePair.one = mouseLocation;
		nextMovePair.two = nextRoom;

		if (!checkMaze(myRoom, nextMovePair)) {
			mouseLocation = nextRoom;
		}
		else
		{
			printPair(nextMovePair);
		}
	}

	if (matchRoom(mouseLocation, cheeseRoom)) {
		cout << endl << "Congratulations, you have won the game." << endl;
	}
	else
	{
		cout << endl << "You have quit the game successfully." << endl;
	}
}