#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,k,l;
	clrscr();
	for(i=1;i<=5;i++)
	{
		for(l=1;l<=9;l++)
		{
			if(l%2!=0)
			{
				if(i==1 || i==5)
				{
					for(j=1;j<=1;j++)
					{
						printf("*");
					}
				}
				else
				{
					for(j=1;j<=1 && ((l==1 || l==9));j++)
					{
						printf("*");
					}
				}
			}
			else
			{
				if(i==1 || i==5)
				{
					for(k=1;k<=1;k++)
					{
						printf(" ");
					}
				}
				else
				{
				}
			}
			if(i>1 && i<5 && l>1 && l<9)
			{
				for(k=1;k<=1;k++)
				{
					printf(" ");
				}
			}
		}
		printf("\n");
	}
	getch();
}