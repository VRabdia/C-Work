#include<stdio.h>
#include<conio.h>
void main()
{
	int math,phy,chem,eng,comp,total,min,max,pr=0;
	clrscr();
	printf("Enter marks for Maths: ");
	scanf("%d",&math);
	printf("\nEnter marks for Physics: ");
	scanf("%d",&phy);
	printf("\nEnter marks for Chemistry: ");
	scanf("%d",&chem);
	printf("\nEnter marks for English: ");
	scanf("%d",&eng);
	printf("\nEnter marks for Computer: ");
	scanf("%d",&comp);

	total=math+phy+chem+eng+comp; //TOTAL

	//MAX

	if(math>phy && math>chem && math>eng && math>comp)
	{
		max=math;
	}
	else if(phy>chem && phy>eng && phy>comp)
	{
		max=phy;
	}
	else if(chem>eng && chem>comp)
	{
		max=chem;
	}
	else if(eng>comp)
	{
		max=eng;
	}
	else
	{
		max=comp;
	}

	//MIN

	if(math<phy && math<chem && math<eng && math<comp)
	{
		min=math;
	}
	else if(phy<chem && phy<eng && phy<comp)
	{
		min=phy;
	}
	else if(chem<eng && chem<comp)
	{
		min=chem;
	}
	else if(eng<comp)
	{
		min=eng;
	}
	else
	{
		min=comp;
	}

	pr=total/5; //PERCENTAGE

	printf("s1 s2 s3 s4 s5 total min max pr\tgrade\tresult");
	printf("\n%d %d %d %d %d %d   %d  %d  %d",math,phy,chem,eng,comp,total,min,max,pr);

	//GRADE

	if(pr>80)
	{
		printf("\tA");
	}
	else if(pr>60)
	{
		printf("\tB");
	}
	else if(pr>35)
	{
		printf("\tC");
	}
	else
	{
		printf("\tD");
	}

	//RESULT

	if(pr>35)
	{
		printf("\tPASS");
	}
	else
	{
		printf("\tFAIL");
	}




	getch();
}