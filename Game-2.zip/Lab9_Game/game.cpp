#include <iostream>
#include "maze.hpp"

using std::cout; using std::cin; using std::endl;

int main() {

	// srand(time(nullptr)); // random seed
	srand(2); // fixed seed

	Maze maze;
	Room cheeseRoom;
	cheeseRoom.makeCheeseRoom();
	maze.build();

	cout << "Would you like to see the Walls of the Maze? (y)es (n)o: ";
	char userInput;
	cin >> userInput;
	if (userInput == 'y') {
		maze.print();
		cout << endl;
	}

	maze.start();

	while (!matchRoom(maze.getCurrentRoom(), cheeseRoom) && !matchRoom(maze.getCurrentRoom(), Room())) {
		Room currentRoom = maze.getCurrentRoom();
		cout << "Current Mouse Room: ";
		currentRoom.print();
		cout << endl;
		Room nextRoom = maze.getCurrentRoom().nextMove();
		RoomPair rp(currentRoom, nextRoom);
		
		if (maze.move(nextRoom)) {
			cout << "Move Successful" << endl;
		}
		else
		{
			cout << "Move Unsuccessful" << endl;
			rp.print();
			cout << endl;
		}

		if (matchRoom(maze.getCurrentRoom(), cheeseRoom)) {
			cout << "Congratulations, you won the game!!!" << endl;
		}
		else if (matchRoom(maze.getCurrentRoom(), Room())) {
			cout << "You have quit the game successfuly!!!" << endl;
		}
	}
}