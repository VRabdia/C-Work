#include<stdio.h>
#include<conio.h>
void main()
{
	clrscr();

	printf("* * * *  * * * *  * * * *     *     * * * *  * * * * *       * * * * * \n");
	printf("*        *     *  *          * *      * *      * *    *     *  *       \n");
	printf("*        * * * *  * * * *   *   *     * *      * *     *   *   * * * * \n");
	printf("*        *   *    *        * * * *    * *      * *      * *    *       \n");
	printf("* * * *  *     *  * * * * *       *   * *    * * * *     *     * * * * \n");

	getch();
}