#include<stdio.h>
#include<conio.h>
void main()
{
	int n,cnt=0,remainder;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	while(remainder!=0)
	{
		if(n%10!=0)
		{
			remainder=n%10;
			cnt++;
			n=n/10;
		}
		else
		{
			remainder=n%10;
		}
	}
	printf("Number Of Digits=%d",cnt);
	getch();
}