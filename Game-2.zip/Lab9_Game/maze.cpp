#include <iostream>
#include "maze.hpp"

using std::cout; using std::cin; using std::endl;


// Room Class

Room::Room() : x_(-1), y_('*') {}

void Room::pick() {
	x_ = rand() % mazeSize_ + 1;
	y_ = 'a' + rand() % mazeSize_;
}

bool Room::goodDirection(const char dr) const {
	bool result;
	if (dr == 'l' && x_ == 1)
	{
		result = false;
	}
	else if (dr == 'r' && x_ == mazeSize_)
	{
		result = false;
	}
	else if (dr == 'u' && y_ == 'a')
	{
		result = false;
	}
	else if (dr == 'd' && y_ == 'a' + mazeSize_ - 1)
	{
		result = false;
	}
	else
	{
		result = true;
	}
	return result;
}

const Room Room::createAdjacent(const char dr) const {
	Room newRoom;
	newRoom.x_ = x_;
	newRoom.y_ = y_;
	if (dr == 'l')
	{
		newRoom.x_ = x_ - 1;
	}
	else if (dr == 'r')
	{
		newRoom.x_ = x_ + 1;
	}
	else if (dr == 'u')
	{
		newRoom.y_ = y_ - 1;
	}
	else if (dr == 'd')
	{
		newRoom.y_ = y_ + 1;
	}
	return newRoom;
}

const Room Room::pickAdjacent() {
	Room randomRoom;
	char dr = '0';
	while (dr == '0')
	{
		int randomDr = rand() % 4;
		switch (randomDr)
		{
		case 0:
			dr = 'u';
			break;
		case 1:
			dr = 'd';
			break;
		case 2:
			dr = 'l';
			break;
		case 3:
			dr = 'r';
			break;
		default:
			break;
		}

		if (goodDirection(dr))
		{
			randomRoom = createAdjacent(dr);
		}
		else
		{
			dr = '0';
		}
	}
	return randomRoom;
}

bool matchRoom(const Room& r1, const Room& r2) {
	if (r1.x_ == r2.x_ && r1.y_ == r2.y_)
	{
		return true;
	}
	else
	{
		return false;
	}
}

const Room Room::nextMove() const {
	cout << "Enter new adjacent room (u)p, (d)own, (l)eft, (r)ight, or (q)uit: ";
	char dr;
	cin >> dr;
	Room newMoveRoom;
	newMoveRoom.x_ = x_;
	newMoveRoom.y_ = y_;
	if (goodDirection(dr)) {
		if (dr == 'l')
		{
			newMoveRoom.x_ = x_ - 1;
		}
		else if (dr == 'r')
		{
			newMoveRoom.x_ = x_ + 1;
		}
		else if (dr == 'u')
		{
			newMoveRoom.y_ = y_ - 1;
		}
		else if (dr == 'd')
		{
			newMoveRoom.y_ = y_ + 1;
		}
		else if (dr == 'q')
		{
			newMoveRoom.x_ = -1;
			newMoveRoom.y_ = '*';
		}
	}
	return newMoveRoom;
}

void Room::print() const {
	cout << x_ << y_;
}

// RoomPair Class

void RoomPair::pick() {
	one_.pick();
	two_ = one_.pickAdjacent();
}

void RoomPair::print() const {
	one_.print();
	cout << "|";
	two_.print();
	cout << ", ";
}

bool matchPair(const RoomPair& rp1, const RoomPair& rp2) {
	if ((matchRoom(rp1.one_, rp2.one_) && matchRoom(rp1.two_, rp2.two_)) || (matchRoom(rp1.one_, rp2.two_) && matchRoom(rp1.two_, rp2.one_)))
	{
		return true;
	}
	else
	{
		return false;
	}
}

// Maze Class

void Maze::print() const {
	for (int i = 0; i < numWalls_; i++) {
		walls_[i].print();
	}
}

void Maze::build() {
	for (int i = 0; i < numWalls_; i++) {
		walls_[i].pick();
	}
}

bool Maze::move(const Room& room) {
	if (!checkMaze(RoomPair(currentRoom_, room))) {
		currentRoom_ = room;
		return true;
	}
	else {
		return false;
	}
}

bool Maze::checkMaze(const RoomPair& rp) const {
	for (int i = 0; i < numWalls_; i++) {
		if (matchPair(walls_[i], rp)) {
			return true;
		}
	}
	return false;
}