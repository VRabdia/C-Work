#include<stdio.h>
#include<conio.h>
void tri()
{
	float area,b,h;
	printf("Enter Base:");
	scanf("%f",&b);
	printf("Enter Height:");
	scanf("%f",&h);
	area=(b*h)/2;
	printf("\nArea Of Triangle Is %.2f",area);
}
void cir()
{
	float pi=3.14,r,area;
	printf("Enter Radius:");
	scanf("%f",&r);
	area=2*pi*r;
	printf("\nArea Of Circle Is %.2f",area);
}
void rec()
{
	int l,b,area;
	printf("Enter Length:");
	scanf("%d",&l);
	printf("Enter Broadness:");
	scanf("%d",&b);
	area=l*b;
	printf("\nArea Of Rectangle Is %d",area);
}
void squ()
{
	int l,area;
	printf("Enter Length:");
	scanf("%d",&l);
	area=l*l;
	printf("\nArea Of Square Is %d",area);
}
void main()
{
	int ch;
	clrscr();
	sc:
	printf("1:Area Of Triangle");
	printf("\n2:Area Of Circle");
	printf("\n3:Area Of Rectangle");
	printf("\n4:Area Of Square");
	printf("\n\nEnter Choice:");
	scanf("%d",&ch);
	clrscr();
	switch(ch)
	{
		case 1:
		{
			tri();
			break;
		}
		case 2:
		{
			cir();
			break;
		}
		case 3:
		{
			rec();
			break;
		}
		case 4:
		{
			squ();
			break;
		}
		default:
		{
			clrscr();
			printf("INVALID CHOICE..!!\n\n");
			goto sc;
		}
	}
	getch();
}