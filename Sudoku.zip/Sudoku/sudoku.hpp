#include <cstdlib>
#include <ctime>
#include <vector>

using std::vector;

#ifndef SUDOKU_HPP_
#define SUDOKU_HPP_

bool match(vector<int> , int);

bool xorMatch(bool, bool, bool);

#endif // SUDOKU_HPP_