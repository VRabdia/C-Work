#include<stdio.h>
#include<conio.h>
void main()
{
	int n,sum,d1,d2,d3;
	clrscr();
	n=1;
	while(n<=900)
	{
		d1=n-((n/10)*10);
		d2=(n/10)-((n/100)*10);
		d3=(n/100)-((n/1000)*10);
		sum=(d1*d1*d1)+(d2*d2*d2)+(d3*d3*d3);
		if(sum==n)
		{
			printf("\n%d",sum);
		}
		n++;
	}
	getch();
}