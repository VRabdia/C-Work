#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c,d,e;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("\nEnter b:");
	scanf("%d",&b);
	printf("\nEnter c:");
	scanf("%d",&c);
	(a>b && a>c)?printf("a is max"):(b>c)?printf("b is max"):printf("c is max");
	getch();
}