#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,k;
	clrscr();
	for(i=1,k=1;i<=5;i++)
	{
		for(j=1;j<=i;j++)
		{
			if(j==1 || j==i)
			{
				k=1;
			}
			else if(j==2 || j==i-1)
			{
				k=i-1;
			}
			else
			{
				k=i+1;
			}
			printf("%d",k);
		}
		k=1;
		printf("\n");
	}
	getch();
}