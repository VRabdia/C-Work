#include<stdio.h>
#include<conio.h>
void main()
{
	char s[100],i,sc=0,uc=0,lc=0,n=0,sp=0;
	clrscr();
	printf("Enter String:");
	gets(s);
	for(i=0;s[i]!=0;i++)
	{
		if(s[i]>=65 && s[i]<=90)
		{
			uc++;
		}
		else if(s[i]>=97 && s[i]<=122)
		{
			lc++;
		}
		else if(s[i]>=48 && s[i]<=57)
		{
			n++;
		}
		else if(s[i]==32)
		{
			sp++;
		}
		else
		{
			sc++;
		}
	}
	printf("\nThere Are %d Upper Case Characters In Given String.",uc);
	printf("\nThere Are %d Lower Case Characters In Given String.",lc);
	printf("\nThere Are %d Numbers In Given String.",n);
	printf("\nThere Are %d Spaces In Given String.",sp);
	printf("\nThere Are %d Special Characters In Given String.",sc);
	getch();
}