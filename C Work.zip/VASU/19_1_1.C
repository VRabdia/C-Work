#include<stdio.h>
#include<conio.h>
void sum()
{
	int a,b;
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);
	printf("\n\na = %d\nb = %d\n\nSum = %d",a,b,a+b);
}
void sub()
{
	int a,b;
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);
	printf("\n\na = %d\nb = %d\n\nSub = %d",a,b,a-b);
}
void mul()
{
	int a,b;
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);
	printf("\n\na = %d\nb = %d\n\nMul = %d",a,b,a*b);
}
void div()
{
	int a,b;
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);
	printf("\n\na = %d\nb = %d\n\nDiv = %d",a,b,a/b);
}
void main()
{
	int ch;
	clrscr();
	sc:
	printf("1:SUM");
	printf("\n2:SUB");
	printf("\n3:MUL");
	printf("\n4:DIV");
	printf("\n\nEnter Choice:");
	scanf("%d",&ch);
	clrscr();
	switch(ch)
	{
		case 1:
		{
			sum();
			break;
		}
		case 2:
		{
			sub();
			break;
		}
		case 3:
		{
			mul();
			break;
		}
		case 4:
		{
			div();
			break;
		}
		default:
		{
			clrscr();
			printf("INVALID CHOICE..!!\n\n");
			goto sc;
		}
	}
	getch();
}