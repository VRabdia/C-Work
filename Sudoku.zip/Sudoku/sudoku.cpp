#include <stdio.h>
#include <vector>
#include <iostream>
#include <ctime>
#include <cstdlib>
#include "sudoku.hpp"

using std::vector; using std::cout; using std::endl;

int main()
{
    srand(time(nullptr));

    std::unique_ptr<std::vector<std::vector<int>>> box(new std::vector<std::vector<int>>(9, std::vector<int>(9, 0)));
    std::unique_ptr<std::vector<std::vector<int>>> row(new std::vector<std::vector<int>>(9, std::vector<int>(9, 0)));
    std::unique_ptr<std::vector<std::vector<int>>> col(new std::vector<std::vector<int>>(9, std::vector<int>(9, 0)));
    std::unique_ptr<std::vector<std::vector<int>>> grid(new std::vector<std::vector<int>>(9, std::vector<int>(9, 0)));

    int num = 0;
    int cnt = 0;

    for (size_t i = 0; i < grid->size(); ++i)
    {
        for (size_t j = 0; j < (*grid)[i].size(); ++j)
        {
            do
            {
                num = (rand()%9)+1;
                
                bool boxResult = match((*box)[(i / 3) * 3 + (j / 3)], num);
                bool rowResult = match((*row)[i], num);
                bool colResult = match((*col)[j], num);


                if (cnt>5000)
                {
                    for (size_t m = 0; m < grid->size(); ++m) {
                        for (size_t n = 0; n < (*grid)[m].size(); ++n) {
                            (*grid)[m][n] = 0;
                        }
                    }

                    for (size_t m = 0; m < box->size(); ++m) {
                        for (size_t n = 0; n < (*box)[m].size(); ++n) {
                            (*box)[m][n] = 0;
                        }
                    }

                    for (size_t m = 0; m < row->size(); ++m) {
                        for (size_t n = 0; n < (*row)[m].size(); ++n) {
                            (*row)[m][n] = 0;
                        }
                    }

                    for (size_t m = 0; m < col->size(); ++m) {
                        for (size_t n = 0; n < (*col)[m].size(); ++n) {
                            (*col)[m][n] = 0;
                        }
                    }
                    i = 0;
                    j = 0;
                    cnt = 0;
                    system("cls");
                }

                cnt++;

            } while (match((*box)[(i / 3) * 3 + (j / 3)], num) || match((*row)[i], num) || match((*col)[j], num));

            (*row)[i][j] = num;
            (*col)[j][i] = num;
            (*box)[(i / 3) * 3 + (j / 3)][(i % 3) * 3 + (j % 3)] = num;
            (*grid)[i][j] = num;
            if (j % 3 == 0)
            {
                cout << "  ";
            }
            else
            {
                cout << " ";
            }
            cout << (*grid)[i][j];
        }
        if (i % 3 == 2)
        {
            cout << endl;
        }
        cout << endl;

    }

    return 0;
}