#include<stdio.h>
#include<conio.h>
void main()
{
	int a[100],n,i,sum;
	clrscr();
	printf("Enter Size Of Data:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("A[%d] = ",i);
		scanf("%d",&a[i]);
	}
	for(i=0,sum=0;i<n;i++)
	{
		sum=sum+a[i];
	}
	printf("Sum Of Data = %d",sum);
	getch();
}