#include<stdio.h>
#include<conio.h>
void main()
{
	int i,n;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	for(i=1;i<=10;i++)
	{
		printf("\n%d\t%d\t%d",n,i,n*i);
	}
	getch();
}