#include<stdio.h>
#include<conio.h>
void main()
{
	char a;
	clrscr();
	printf("Enter Character:");
	scanf("%c",&a);
	printf("\nASCII CODE:%d",a);
	getch();
}