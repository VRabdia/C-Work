#include<stdio.h>
#include<conio.h>
struct name
{
	char s[100],*a[100],*temp[100];
};
void main()
{
	struct name x[100];
	char n,i,j;
	clrscr();
	printf("Enter Total Number Of Names:");
	scanf("%d",&n);
	flushall();
	for(i=0;i<n;i++)
	{
		printf("Enter Name:");
		gets(x[i].s);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;x[i].s[j]!=0;j++)
		{
			x[i].a[j]=&x[i].s[j];
			/*printf("\n%c",*x[i].a[j]);*/
		}
	}
	for(i=0;i<=n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if((strcmp(x[i].s,x[j].s))>0)
			{
				strcpy(*x[i].temp,*x[i].a);
				/*printf("\nx[%d].temp=%s\tx[%d].a=%s",i,*x[i].temp,i,*x[i].a);*/
				strcpy(*x[i].a,*x[j].a);
				/*printf("\nx[%d].a=%s\tx[%d].a=%s",i,*x[i].a,j,*x[j].a);*/
				strcpy(*x[j].a,*x[i].temp);
				/*printf("\nx[%d].a=%s\tx[%d].temp=%s",j,*x[j].a,i,*x[i].temp);*/
			}
		}
	}
	printf("\n\n\nSorted Order:");
	for(i=0;i<n;i++)
	{
		printf("\n%s",*x[i].a);
	}
	getch();
}