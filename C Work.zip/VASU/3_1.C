#include<stdio.h>
#include<conio.h>
void main()
{
	int n1,n2,x;
	clrscr();
	printf("Enter first number: ");
	scanf("%d",&n1);
	printf("\nEnter second number: ");
	scanf("%d",&n2);
	printf("\nBefore swap a=%d and b=%d",n1,n2);
	x=n1;
	n1=n2;
	n2=x;
	printf("\nAfter swap a=%d and b=%d",n1,n2);

	getch();
}