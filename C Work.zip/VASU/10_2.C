#include<stdio.h>
#include<conio.h>
void main()
{
	int n,i=1;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);

	do
	{
		printf("\n%d cube=%d",i,i*i*i);
		i++;
	}while(i<=n);
	getch();
}