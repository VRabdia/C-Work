#include<stdio.h>
#include<conio.h>
void main()
{
	int i=1;
	clrscr();
	while(i<=10)
	{
		printf("\n%d",i);
		i++;
	}
	getch();
}