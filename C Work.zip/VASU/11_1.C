#include<stdio.h>
#include<conio.h>
void main()
{
	int n,a,b,sum;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	for(a=0,b=1,sum=0;a<=n;)
	{
		sum=a+b;
		printf("\n%d",a);
		a=b;
		b=sum;
	}
	getch();
}