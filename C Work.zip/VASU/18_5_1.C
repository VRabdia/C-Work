#include<stdio.h>
#include<conio.h>
void main()
{
	char n[100],cnt=0,i;
	clrscr();
	printf("Enter Name:");
	gets(n);
	for(i=0;n[i]!=0;i++)
	{
		cnt++;
	}
	printf("\nLength Of Given String Is %d",cnt);
	getch();
}
