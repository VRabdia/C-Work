#include<stdio.h>
#include<stdio.h>
void main()
{
	FILE *f;
	char *c,a;
	int sc;
	clrscr();
	beg:
	printf("1:WRITE FILE");
	printf("\n2:READ FILE");
	printf("\n3:APPEND FILE");
	printf("\n\nEnter Choice:");
	scanf("%d",&sc);
	switch(sc)
	{
		case 1:
		{
			clrscr();
			printf("Enter String:");
			flushall();
			gets(c);
			f=fopen("demo.txt","w");
			fputs(c,f);
			fclose(f);
			break;
		}
		case 2:
		{
			clrscr();
			f=fopen("demo.txt","r");
			while((a=fgetc(f))!=EOF)
			{
				printf("%c",a);
			}
			break;
		}
		case 3:
		{
			clrscr();
			printf("Enter String:");
			flushall();
			gets(c);
			f=fopen("demo.txt","a");
			fputs(c,f);
			fclose(f);
			break;
		}
		default:
		{
			clrscr();
			printf("Wrong Choice..!!\n\n\n");
		}
	}
	getch();
}