#include<stdio.h>
#include<conio.h>
#include"19_5_2.h"
void main()
{
	int m;
	clrscr();
	m=max();
	printf("\n\nMax = %d",m);
	getch();
}