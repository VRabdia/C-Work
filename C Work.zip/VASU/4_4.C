#include<stdio.h>
#include<conio.h>
void main()
{
	float si;
	int p,n,r;
	clrscr();
	printf("Enter the Amount: ");
	scanf("%d",&p);
	printf("\nEnter the Rate: ");
	scanf("%d",&r);
	printf("\nEnter the Number of Years: ");
	scanf("%d",&n);
	si=(p*r*n)/100;
	printf("\nSimple Interest: %f",si);

	getch();
}