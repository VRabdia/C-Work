#include<stdio.h>
#include<conio.h>
void main()
{
	char n[100],cnt=0,i;
	clrscr();
	printf("Enter String:");
	gets(n);
	for(i=0;n[i]!=0;i++)
	{
		if((n[i]>=65 && n[i]<=90) || (n[i]>=97 && n[i]<=122))
		{
			cnt++;
		}
	}
	printf("\nTotal Number Of Alphabets In Given String Is %d",cnt);
	getch();
}