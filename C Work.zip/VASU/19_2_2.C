#include<stdio.h>
#include<conio.h>
#include"19_2_2.h"
void main()
{
	float area;
	int ch;
	clrscr();
	sc:
	printf("1:Area Of Triangle");
	printf("\n2:Area Of Circle");
	printf("\n3:Area Of Rectangle");
	printf("\n4:Area Of Square");
	printf("\n\nEnter Choice:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:
		{
			area=tri();
			printf("Area = %.2f",area);
			break;
		}
		case 2:
		{
			area=cir();
			printf("Area = %.2f",area);
			break;
		}
		case 3:
		{
			area=rec();
			printf("Area = %.2f",area);
			break;
		}
		case 4:
		{
			area=squ();
			printf("Area = %.2f",area);
			break;
		}
		default:
		{
			clrscr();
			printf("INVALID CHOICE..!!\n\n");
			goto sc;
		}
	}
	getch();
}