#include<stdio.h>
#include<conio.h>
void main()
{
	int a[100],i,n;
	clrscr();
	printf("Enter Size Of Data:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("A[%d] = ",i);
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		printf("\nA[%d] = %d",i,a[i]);
	}
	printf("\nOn Which Position Would You Like To Replace The Data:");
	scanf("%d",&i);
	printf("\nEnter New Data:");
	scanf("%d",&a[i]);
	printf("\nNew Data");
	for(i=0;i<n;i++)
	{
		printf("\nA[%d] = %d",i,a[i]);
	}
	getch();
}