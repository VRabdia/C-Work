#include<stdio.h>
#include<conio.h>
void main()
{
	char a[100];
	clrscr();
	printf("Enter Character:");
	gets(a);
	printf("\n\n%s",a);
	getch();
}