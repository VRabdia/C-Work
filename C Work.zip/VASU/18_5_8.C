#include<stdio.h>
#include<conio.h>
void main()
{
	char s[100],cnt=0,i;
	clrscr();
	printf("Enter String:");
	gets(s);
	for(i=0;s[i]!=0;i++)
	{
		if((s[i]>=48 && s[i]<=57) || (s[i]>=65 && s[i]<=90) || (s[i]>=97 && s[i]<=122))
		{
		}
		else
		{
			cnt++;
		}
	}
	printf("\nTotal Number Of Special Charecter In Given String Is %d",cnt);
	getch();
}