#include<stdio.h>
#include<conio.h>
struct var
{
	char s[100],temp[100];
};
void main()
{
	struct var x[100];
	int n,i,j;
	clrscr();
	printf("Enter Total Number Of Names:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Enter Name:");
		scanf("%s",&x[i].s);
	}
	for(i=0;i<=n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(strcmp(x[i].s,x[j].s)>0)
			{
				strcpy(x[i].temp[i],x[i].s);
				strcpy(x[i].s,x[j].s);
				strcpy(x[j].s,x[i].temp[i]);
			}
		}
	}
	printf("\n\nSort Order:");
	for(i=0;i<n;i++)
	{
		printf("\n");
		printf("%s",&x[i].s);
	}
	getch();
}