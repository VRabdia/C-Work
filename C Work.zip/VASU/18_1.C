#include<stdio.h>
#include<conio.h>
void main()
{
	char a;
	clrscr();
	printf("Enter Character:");
	scanf("%c",&a);
	printf("\n%c",a);
	getch();
}