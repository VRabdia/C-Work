#include<stdio.h>
#include<conio.h>
void sum()
{
	int a[100][100],i,j,r,c,rsum,csum;
	printf("Enter Number Of Rows:");
	scanf("%d",&r);
}
void main()
{
	clrscr();
	sum();
	getch();
}