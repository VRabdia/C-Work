#include<stdio.h>
#include<conio.h>
void fact(int n)
{
	int i,fact=1;
	for(i=1;i<=n;i++)
	{
		fact=fact*i;
	}
	printf("\n\nFactorial = %d",fact);
}
void main()
{
	int n;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	fact(n);
	getch();
}