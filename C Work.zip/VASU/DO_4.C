#include<stdio.h>
#include<conio.h>
void main()
{
	int a=1;
	clrscr();
	do
	{
		if(a%2==0)
		{
			printf("\n%d",a);
			a++;
		}
		else
		{
			a++;
		}
	}while(a<=10);
	getch();
}