#include<stdio.h>
#include<conio.h>
void main()
{
	int s1,s2,s3,s4,s5,total,min,max,result,grade;
	float pr=0;
	clrscr();
	printf("Enter s1:");
	scanf("%d",&s1);
	printf("\nEnter s2:");
	scanf("%d",&s2);
	printf("\nEnter s3:");
	scanf("%d",&s3);
	printf("\nEnter s4:");
	scanf("%d",&s4);
	printf("\nEnter s5:");
	scanf("%d",&s5);
	total=s1+s2+s3+s4+s5; //TOTAL
	pr=total/5; //PR
	//MIN
	if(s1<s2 && s1<s3 && s1<s4 && s1<s5)
	{
		min=s1;
	}
	else if(s2<s3 && s2<s4 && s2<s5)
	{
		min=s2;
	}
	else if(s3<s4 && s3<s5)
	{
		min=s3;
	}
	else if(s4<s5)
	{
		min=s4;
	}
	else
	{
		min=s5;
	}

	//MAX
	if(s1>s2 && s1>s3 && s1>s4 && s1>s5)
	{
		max=s1;
	}
	else if(s2>s3 && s2>s4 && s2>s5)
	{
		max=s2;
	}
	else if(s3>s4 && s3>s5)
	{
		max=s3;
	}
	else if(s4>s5)
	{
		max=s4;
	}
	else
	{
		max=s5;
	}

	printf("s1 s2 s3 s4 s5 total min max pr\t\tgrade\tresult");
	printf("\n%d %d %d %d %d %d   %d  %d  %.2f",s1,s2,s3,s4,s5,total,min,max,pr);

	//GRADE
	if(pr>90)
	{
		printf("\tA1");
	}
	else if(pr>70)
	{
		printf("\tA2");
	}
	else if(pr>60)
	{
		printf("\tB1");
	}
	else if(pr>50)
	{
		printf("\tB2");
	}
	else if(pr>40)
	{
		printf("\tC1");
	}
	else if(pr>35)
	{
		printf("\tC2");
	}
	else
	{
		printf("\tD");
	}

	//RESULT

	if(s1<35 && s2<35 && s3<35 && s4<35)
	{
		printf("\tFAIL");
	}
	else if(s1<35 && s2<35 && s3<35 && s5<35)
	{
		printf("\tFAIL");
	}
	else if(s1<35 && s2<35 && s4<35 && s5<35)
	{
		printf("\tFAIL");
	}
	else if(s1<35 && s3<35 && s4<35 && s5<35)
	{
		printf("\tFAIL");
	}
	else if(s2<35 && s3<35 && s4<35 && s5<35)
	{
		printf("\tFAIL");
	}
	else if(s1<35 || s2<35 || s3<35 || s4<35 || s5<35)
	{
		printf("\tAT/KT");
	}
	else
	{
		printf("\tPASS");
	}


	getch();
}