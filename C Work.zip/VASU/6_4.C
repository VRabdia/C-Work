#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c,d,e;
	clrscr();
	printf("Enter a: ");
	scanf("%d",&a);
	printf("\nEnter b: ");
	scanf("%d",&b);
	printf("\nEnter c: ");
	scanf("%d",&c);
	printf("\nEnter d: ");
	scanf("%d",&d);
	printf("\nEnter e: ");
	scanf("%d",&e);

	if(a>b)
	{
		if(a>c)
		{
			if(a>d)
			{
				if(a>e)
				{
					printf("%d is max",a);
				}
				else
				{
					printf("%d is max",e);
				}
			}
			else
			{
				if(d>e)
				{
					printf("%d is max",d);
				}
				else
				{
					printf("%d is max",e);
				}

			}
		}
		else
		{
			if(c>d)
			{
				if(c>e)
				{
					printf("%d is max",c);
				}
				else
				{
					printf("%d is max",e);
				}
			}
			else
			{
				if(d>e)
				{
					printf("%d is max",d);
				}
				else
				{
					printf("%d is max",e);
				}
			}
		}
	}
	else
	{
		if(b>c)
		{
			if(b>d)
			{
				if(b>e)
				{
					printf("%d is max",b);
				}
				else
				{
					printf("%d is max",e);
				}
			}
			else
			{
				if(d>e)
				{
					printf("%d is max",d);
				}
				else
				{
					printf("%d is max",e);
				}
			}
		}
		else
		{
			if(c>d)
			{
				if(c>e)
				{
					printf("%d is max",c);
				}
				else
				{
					printf("%d is max",e);
				}
			}
			else
			{
				if(d>e)
				{
					printf("%d is max",d);
				}
				else
				{
					printf("%d is max",e);
				}
			}
		}
	}
	getch();
}