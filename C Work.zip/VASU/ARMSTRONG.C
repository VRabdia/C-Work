#include<stdio.h>
#include<conio.h>
void main()
{
	int n,r,cube,sum=0,a;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	a=n;
	while(n>0)
	{
		r=n%10;
		cube=r*r*r;
		sum=sum+cube;
		printf("\nsum=%d",sum);
		n=n/10;
	}

	if(a==sum)
	{
		printf("\n%d is an armstrong number",a);
	}
	else
	{
		printf("\n%d is not an armstrong number",a);
	}
	getch();
}