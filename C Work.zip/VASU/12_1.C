#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,sum=0,avg;
	clrscr();
	for(i=1;i<=5;i++)
	{
		printf("Enter Value:");
		scanf("%d",&j);
		if(j<0)
		{
			goto a;
		}
		else
		{
			sum=sum+j;
			avg=sum/5;
		}
	}
	a:
	printf("\nSum:%d",sum);
	printf("\nAvg:%d",avg);
	getch();
}