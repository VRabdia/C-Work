#include<stdio.h>
#include<conio.h>
void main()
{
	int a=1;
	clrscr();
	do
	{
		if(a%2==0)
		{
			a++;
		}
		else
		{
			printf("\n%d",a);
			a++;
		}
	}while(a<=10);
	getch();
}