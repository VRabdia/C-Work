#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c,ch;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);

	printf("1:SUM\n2:SUB\n3:MUL\n4:DIV");
	printf("\nEnter Choice:");
	scanf("%d",&ch);

	switch(ch)
	{
		case 1:
		{
			c=a+b;
			printf("\nSUM:%d",c);
			break;
		}
		case 2:
		{
			c=a-b;
			printf("\nSUB:%d",c);
			break;
		}
		case 3:
		{
			c=a*b;
			printf("\nMUL:%d",c);
			break;
		}
		case 4:
		{
			c=a/b;
			printf("\nDIV:%d",c);
			break;
		}
		default:
		{
			printf("\nWrong Choice...!!!");
		}
	}

	getch();
}