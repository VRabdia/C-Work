#include<stdio.h>
#include<conio.h>
struct var
{
	char s[100][100],temp[100];
};
void main()
{
	struct var x[100];
	int n,i,j;
	clrscr();
	printf("Enter Total Number Of Names:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Enter Name:");
		scanf("%s",&x[i].s[i]);
	}
	for(i=0;i<=n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(strcmp(x[i].s,x[i].s[j])>0)
			{
				strcpy(x[i].temp[i],x[i].s[i]);
				strcpy(x[i].s,x[i].s[j]);
				strcpy(x[i].s[j],x[i].temp[i]);
			}
		}
	}
	printf("Sort Order:\n");
	for(i=0;i<n;i++)
	{
		printf("%s",&x[i].s[i]);
	}
	getch();
}