#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c;
	clrscr();
	printf("Enter first number: ");
	scanf("%d",&a);
	printf("\nEnter second number: ");
	scanf("%d",&b);
	c=a+b;
	printf("\nSum=%d",c);
	c=a-b;
	printf("\nSub=%d",c);
	c=a*b;
	printf("\nMul=%d",c);
	c=a/b;
	printf("\nDiv=%d",c);
	getch();
}