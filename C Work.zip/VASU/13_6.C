#include<stdio.h>
#include<conio.h>
void main()
{
	int a[100],b[100],c[100],n1,n2,i,k;
	clrscr();
	printf("Enter Size Of Data-1:");
	scanf("%d",&n1);
	for(i=0;i<n1;i++)
	{
		printf("A[%d] = ",i);
		scanf("%d",&a[i]);
	}
	printf("Enter Size Of Data-2:");
	scanf("%d",&n2);
	for(i=0;i<n2;i++)
	{
		printf("B[%d] = ",i);
		scanf("%d",&b[i]);
	}
	for(i=0;i<n1;i++)
	{
		c[i]=a[i];
	}
	for(i=n1,k=0;i<n1+n2;i++,k++)
	{
		c[i]=b[k];
	}
	for(i=0;i<n1+n2;i++)
	{
		printf("\nC[%d] = %d",i,c[i]);
	}
	getch();
}