#include<stdio.h>
#include<conio.h>
void main()
{
	int a[100],b[100],i,n;
	clrscr();
	printf("Enter Size Of Data:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("A[%d] = ",i);
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		b[i]=a[n-1-i];
	}
	for(i=0;i<n;i++)
	{
		printf("\nB[%d] = %d",i,b[i]);
	}
	getch();
}