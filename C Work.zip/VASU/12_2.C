#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,sum=0;
	clrscr();
	for(i=1;i<=5;i++)
	{
		printf("Enter Value:");
		scanf("%d",&j);
		if(j<0)
		{
			break;
		}
		else
		{
			sum=sum+j;
		}
	}
	printf("\nSum=%d",sum);
	getch();
}