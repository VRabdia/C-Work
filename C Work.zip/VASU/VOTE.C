#include<stdio.h>
#include<conio.h>
void main()
{
	int age;
	clrscr();
	printf("Enter your Age: ");
	scanf("%d",&age);
	if(age>18)
	{
		printf("You are eligible for voting");
	}
	else
	{
		printf("You are not eligible for voting");
	}

	getch();
}