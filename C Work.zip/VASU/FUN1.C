#include<stdio.h>
#include<conio.h>
void array()
{
	int a[100][100],i,j,r,c;
	printf("Enter Number Of Rows:");
	scanf("%d",&r);
	printf("Enter Number Of Columns:");
	scanf("%d",&c);
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			printf("A[%d][%d] = ",i,j);
			scanf("%d",&a[i][j]);
		}
	}
	printf("\n\n\n");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			printf("\t%d",a[i][j]);
		}
		printf("\n");
	}
}
void main()
{
	clrscr();
	array();
	getch();
}