#include<stdio.h>
#include<conio.h>
void fact()
{
	int f=1,n,i;
	printf("Enter n:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		f=f*i;
	}
	printf("\n\n%d! = %d",n,f);
}
void main()
{
	clrscr();
	fact();
	getch();
}