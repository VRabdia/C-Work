#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);
	while(a<b)
	{
		printf("a is min");
		a=b;
	}
	while(a>b)
	{
		printf("b is min");
		b=a;
	}
	getch();
}