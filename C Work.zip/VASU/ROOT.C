#include<stdio.h>
#include<conio.h>
void main()
{
	float a,b,c,d=1;
	clrscr();
	printf("\nEnter c:");
	scanf("%d",&c);
	loop:
	a = 0.5*(b+(c/b));
	if(a==d)
	{
		printf("\n\n%d",a);
	}
	else
	{
		a = d;
		b = a;
		goto loop;
	}
	getch();
}