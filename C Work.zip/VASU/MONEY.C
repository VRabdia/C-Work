#include<stdio.h>
#include<conio.h>
void main()
{
	int n2000,n500,n200,n100,n50,n20,n10,n5,n2,n1,n,i,temp;
	clrscr();
	printf("Enter Amount:");
	scanf("%d",&n);
	temp=n;
	if(n>=2000)
	{
		n2000=temp/2000;
		temp=temp%2000;
	}
	if(n>=500)
	{
		n500=temp/500;
		temp=temp%500;
	}
	if(n>=200)
	{
		n200=temp/200;
		temp=temp%200;
	}
	if(n>=100)
	{
		n100=temp/100;
		temp=temp%100;
	}
	if(n>=50)
	{
		n50=temp/50;
		temp=temp%50;
	}
	if(n>=20)
	{
		n20=temp/20;
		temp=temp%20;
	}
	if(n>=10)
	{
		n10=temp/10;
		temp=temp%10;
	}
	if(n>=5)
	{
		n5=temp/5;
		temp=temp%5;
	}
	if(n>=2)
	{
		n2=temp/2;
		temp=temp%2;
	}
	if(n>=1)
	{
		n1=temp/1;
		temp=temp%1;
	}
	//OUTPUT
	printf("\n2000 * %d = %d",n2000,n2000*2000);
	printf("\n500 * %d = %d",n500,n500*500);
	printf("\n200 * %d = %d",n200,n200*200);
	printf("\n100 * %d = %d",n100,n100*100);
	printf("\n50 * %d = %d",n50,n50*50);
	printf("\n20 * %d = %d",n20,n20*20);
	printf("\n10 * %d = %d",n10,n10*10);
	printf("\n5 * %d = %d",n5,n5*5);
	printf("\n2 * %d = %d",n2,n2*2);
	printf("\n1 * %d = %d",n1,n1*1);
	getch();
}