#include<stdio.h>
#include<conio.h>
void main()
{
	int i,n,cnt;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	for(i=1,cnt=0;i<=n;i++)
	{
		if(n%i==0)
		{
			cnt++;
		}
		else
		{
		}
	}
	if(cnt==2)
	{
		printf("\n%d is a prime number.",n);
	}
	else
	{
		printf("\n%d is not a prime number.",n);
	}
	getch();
}