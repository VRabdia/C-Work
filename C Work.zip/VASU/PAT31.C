#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,k,l,m,n,o;
	clrscr();
	for(i=1,l=7,m=13,n=3,o=17;i<=10;i++)
	{
		for(j=1;j<=19;j++)
		{
			if(j%2!=0 && (i==1 || i==10 || j==1 || j==19))
			{
				printf("*");
			}
			else if((j==2 || j==13) && i>1 && i<5)
			{
				if(j==2)
				{
					for(k=j;k<=l;k++)
					{
						if(k%2!=0)
						{
							printf("*");
						}
						else
						{
							printf(" ");
						}
					}
					j=l;
					l=l-2;
				}
				else
				{
					if(i==3)
					{
						printf("  ");
					}
					else if(i==4)
					{
						printf("    ");
					}
					for(k=m;k<=17;k++)
					{
						if(k%2!=0)
						{
							printf("*");
						}
						else
						{
							printf(" ");
						}
					}
					j=k-1;
					m=m+2;
				}
			}
			else if((j==2 || j==14) && i>6 && i<10)
			{
				if(j==2)
				{
					for(k=j;k<=n;k++)
					{
						if(k%2!=0)
						{
							printf("*");
						}
						else
						{
							printf(" ");
						}
					}
					j=k;
					n=n+2;
				}
				else
				{
					if(i==7)
					{
						printf("    ");
					}
					else if(i==8)
					{
						printf("  ");
					}
					for(k=o;k<=17;k++)
					{
						if(k%2!=0)
						{
							printf("*");
						}
						else
						{
							printf(" ");
						}
					}
					j=k-1;
					o=o-2;

				}
			}
			else
			{
				printf(" ");
			}
		}
		printf("\n");
	}
	getch();
}