#include<stdio.h>
#include<conio.h>
void max()
{
	int a[100],i,max;
	for(i=0;i<3;i++)
	{
		printf("\nEnter Number:");
		scanf("%d",&a[i]);
	}
	max=a[0];
	printf("\n\n\n\n");
	for(i=0;i<3;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
		}
	}
	printf("%d Is Max",max);
}
void main()
{
	clrscr();
	max();
	getch();
}