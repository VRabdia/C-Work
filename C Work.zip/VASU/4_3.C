#include<stdio.h>
#include<conio.h>
void main()
{
	int l,b,area;
	clrscr();
	printf("Enter the Length of Rectangle: ");
	scanf("%d",&l);
	printf("\nEnter the Broadnes of Rectangle: ");
	scanf("%d",&b);
	area=l*b;
	printf("\nThe Area of the Rectangle is: %d",area);
	getch();
}