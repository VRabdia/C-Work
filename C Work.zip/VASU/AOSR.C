#include<stdio.h>
#include<conio.h>
struct var
{
	int sub[100],min,max,pr,total,ktcnt;
	char name[100];
};
void main()
{
	struct var s[100];
	int n,i,j,scnt,subcnt,k;
	clrscr();
	printf("Enter Number Of Students:");
	scanf("%d",&n);
	for(i=0,scnt=1;i<n;i++,scnt++)
	{
		printf("Enter Student %d Name:",scnt);
		flushall();
		gets(s[i].name);
		for(k=0,subcnt=1;k<5;k++,subcnt++)
		{
			printf("Enter Subject %d Marks For Student %d:",subcnt,scnt);
			scanf("%d",&s[i].sub[k]);
		}
		//MIN
		s[i].min=s[i].sub[0];
		for(k=0;k<5;k++)
		{
			if(s[i].sub[k]<s[i].min)
			{
				s[i].min=s[i].sub[k];
			}
		}
		//MAX
		s[i].max=s[i].sub[0];
		for(k=0;k<5;k++)
		{
			if(s[i].sub[k]>s[i].max)
			{
				s[i].max=s[i].sub[k];
			}
		}
		//TOTAL
		s[i].total=0;
		for(k=0;k<5;k++)
		{
			s[i].total=s[i].total+s[i].sub[k];
		}
		//PR
		s[i].pr=s[i].total/5;
		//AT/KT
		s[i].ktcnt=0;
		for(k=0;k<5;k++)
		{
			if(s[i].sub[k]<=33)
			{
				s[i].ktcnt++;
			}
		}
	}
	//OUTPUT
	clrscr();
	printf("Name\tS1\tS2\tS3\tS4\tS5\tMin Max\tTotal\tPR\tRes");
	printf("\n\n");
	for(i=0;i<n;i++)
	{
		printf("\n");
		for(j=0;s[i].name[j]!=0;j++)
		{
			printf("%c",s[i].name[j]);
		}
		for(k=0;k<5;k++)
		{
			printf("\t%d",s[i].sub[k]);
		}
		printf("\t%d %d\t%d\t%d",s[i].min,s[i].max,s[i].total,s[i].pr);
		if(s[i].ktcnt<=0)
		{
			printf("\tPass");
		}
		else if(s[i].ktcnt>=4)
		{
			printf("\tFail");
		}
		else
		{
			printf("\tKT");
		}
	}
	getch();
}

/*
Emplyee Name 	Designation 	Salary	Leave	On Hand Salary
*/