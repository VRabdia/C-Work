#include<stdio.h>
#include<conio.h>
void main()
{
	int n,r,rev,temp;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	temp=n;
	for(r=0,rev=0;n>0;)
	{
		r=n%10;
		rev=(rev*10)+r;
		n=n/10;
	}
	if(temp==rev)
	{
		printf("\n%d is a palindrome number.",temp);
	}
	else
	{
		printf("\n%d is not a palindrome number.",temp);
	}
	getch();
}