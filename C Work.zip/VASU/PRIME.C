#include<stdio.h>
#include<conio.h>
void main()
{
	int n,i=2,cnt=0;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	while(i<n)
	{
		if(n%i==0)
		{
			cnt=0;
			i=n;
		}
		else
		{
			i++;
			cnt=1;
		}
	}
	if(cnt==1)
	{
		printf("%d is a prime number",n);
	}
	else
	{
		printf("%d is not a prime number",n);
	}
	getch();
}