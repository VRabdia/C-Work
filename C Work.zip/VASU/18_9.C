#include<stdio.h>
#include<conio.h>
void main()
{
	char s[100],i,del,cnt=0,temp;
	clrscr();
	printf("Enter String:");
	gets(s);
	for(i=0;s[i]!=0;i++)
	{
		printf("%c",s[i]);
		cnt++;
	}
	printf("\nWhat Would You Like To Delete:");
	scanf("%c",&del);
	temp=del;
	loop:
	del=temp;
	for(i=0;i<=cnt;i++)
	{
		if(s[i]==del)
		{
			s[i]=s[i+1];
			del=s[i];
		}
	}
	for(i=0;s[i]!=0;i++)
	{
		if(s[i]==temp)
		{
			goto loop;
		}
	}
	for(i=0;s[i]!=0;i++)
	{
		printf("%c",s[i]);
	}
	getch();
}