#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,k;
	clrscr();
	for(i=1;i<=5;i++)
	{
		if(i%2==0)
		{
			for(k=1;k<=5-i;k++)
			{
				printf(" ");
			}
			for(j=1;j<=i;j++)
			{
				if(j%2==0)
				{
					printf("1");
				}
				else
				{
					printf("0");
				}
			}
		}
		else
		{
			for(k=1;k<=5-i;k++)
			{
				printf(" ");
			}
			for(j=1;j<=i;j++)
			{
				if(j%2==0)
				{
					printf("0");
				}
				else
				{
					printf("1");
				}
			}
		}
		printf("\n");
	}
	getch();
}