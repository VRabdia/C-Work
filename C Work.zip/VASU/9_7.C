#include<stdio.h>
#include<conio.h>
void main()
{
	int n,remainder;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	while(n>0)
	{
		remainder=n%10;
		printf("%d",remainder);
		n=n/10;
	}
	getch();
}