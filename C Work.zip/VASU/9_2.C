#include<stdio.h>
#include<conio.h>
void main()
{
	int i;
	clrscr();
	printf("Enter i:");
	scanf("%d",&i);
	while(i>=1)
	{
		printf("\n%d",i);
		i--;
	}
	getch();
}