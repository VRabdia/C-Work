#include<stdio.h>
#include<conio.h>
void main()
{
	int a[100],i,n,max;
	clrscr();
	printf("Enter Size Of Data:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("A[%d] = ",i);
		scanf("%d",&a[i]);
	}
	for(i=0,max=a[0];i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
		}
	}
	printf("Max = %d",max);
	getch();
}