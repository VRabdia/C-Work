#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,*i,*j,*k;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);
	i=&a;
	j=&b;
	printf("\n\nBefore Swap:\ta =\t%d\tb =\t%d",*i,*j);
	k=i;
	i=j;
	j=k;
	printf("\n\nAfter Swap:\ta =\t%d\tb =\t%d",*i,*j);
	getch();
}