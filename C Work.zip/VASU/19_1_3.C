#include<stdio.h>
#include<conio.h>
void sum(int a,int b)
{
	int c;
	c=a+b;
	printf("\n\nSum = %d",c);
}
void sub(int a,int b)
{
	int c;
	c=a-b;
	printf("\nSub = %d",c);
}
void mul(int a,int b)
{
	int c;
	c=a*b;
	printf("\nMul = %d",c);
}
void div(int a,int b)
{
	int c;
	c=a/b;
	printf("\nDiv = %d",c);
}
void main()
{
	int a,b;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);
	sum(a,b);
	sub(a,b);
	mul(a,b);
	div(a,b);
	getch();
}