#include<stdio.h>
#include<conio.h>
#include"19_3_2.h"
void main()
{
	int f;
	clrscr();
	f=fact();
	printf("\n\nFactorial = %d",f);
	getch();
}