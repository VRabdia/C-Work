#include<stdio.h>
#include<conio.h>
void main()
{
	int pass,cnt,temp,r,ch,epass,bal=5500,add,wid,sbal=0,fd,cbal=0;
	clrscr();
	//SET PASSWORD
	do
	{
		clrscr();
		printf("Set Password:");
		scanf("%d",&pass);
		temp=pass;
		cnt=0;
		r=1;
		while(r!=0)
		{
			if(temp%10!=0)
			{
				r=temp%10;
				cnt++;
				temp=temp/10;
			}
			else
			{
				r=0;
			}
		}
	}while(cnt<4);
	//SWITCH CASE 1
	clrscr();
	s1:
	printf("1:ACCESS ACCOUNT");
	printf("\n2:OPEN ACCOUNT");
	printf("\n3:RESET PASSWORD");
	printf("\n4:EXIT");
	ec:
	printf("\nEnter Choice:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:
		{
			clrscr();
			c1ep:
			printf("Enter Password:");
			scanf("%d",&epass);
			if(epass==pass)
			{
				clrscr();
				s2:
				printf("1:ADD BALANCE");
				printf("\n2:WITHDRAW");
				printf("\n3:CHECK BALANCE");
				printf("\n4:RESET PASSWORD");
				printf("\n5:EXIT");
				s2ec:
				printf("\nEnter Choice:");
				scanf("%d",&ch);
				switch(ch)
				{
					case 1:
					{
						clrscr();
						c1c1ep:
						printf("Enter Password:");
						scanf("%d",&epass);
						if(epass==pass)
						{
							clrscr();
							printf("Enter Amount:");
							scanf("%d",&add);
							bal=bal+add;
							clrscr();
							printf("Balance Added Successfully...\n");
							goto s2;
						}
						else
						{
							clrscr();
							printf("Wrong Password..!!\n");
							goto c1c1ep;
						}
						break;
					}
					case 2:
					{
						clrscr();
						c1c2ep:
						printf("Enter Password:");
						scanf("%d",&epass);
						if(epass==pass)
						{
							clrscr();
							c1c2ea:
							printf("Enter Amount:");
							scanf("%d",&wid);
							if(bal-wid>=1000)
							{
								clrscr();
								bal=bal-wid;
								printf("Withdrawal Successfull...\n");
							}
							else
							{
								clrscr();
								printf("Insufficient Funds..!!\n");
								goto c1c2ea;
							}
						}
						else
						{
							clrscr();
							printf("Wrong Password..!!\n");
							goto c1c2ep;
						}
						goto s2;
						break;
					}
					case 3:
					{
						clrscr();
						c1c3ep:
						printf("Enter Password:");
						scanf("%d",&epass);
						if(epass==pass)
						{
							clrscr();
							printf("Your Current Balance Is %d\n",bal);
							goto s2;
						}
						else
						{
							clrscr();
							printf("Wrong Password..!!\n");
							goto c1c3ep;
						}
						break;
					}
					case 4:
					{
						clrscr();
						c1c4ep:
						printf("Enter Current Password:");
						scanf("%d",&epass);
						if(epass==pass)
						{
							do
							{
								clrscr();
								printf("Enter New Password:");
								scanf("%d",&pass);
								temp=pass;
								cnt=0;
								r=1;
								while(r!=0)
								{
									if(temp%10!=0)
									{
										r=temp%10;
										cnt++;
										temp=temp/10;
									}
									else
									{
										r=0;
									}
								}
							}while(cnt<4);
							clrscr();
							printf("Password Reseted Successfully...\n");
						}
						else
						{
							clrscr();
							printf("Wrong Password..!!\n");
							goto c1c4ep;
						}
						goto s2;
						break;
					}
					case 5:
					{
						break;
					}
					default:
					{
						printf("\nINVALID CHOICE..!!");
						goto s2ec;
						break;
					}
				}
			}
			else
			{
				clrscr();
				printf("Wrong Password..!!\n");
				goto c1ep;
			}
			break;
		}
		case 2:
		{
			clrscr();
			c2ep:
			printf("Enter Password:");
			scanf("%d",&epass);
			if(epass==pass)
			{
				clrscr();
				s3:
				printf("1:SAVINGS ACCOUNT");
				printf("\n2:CURRENT ACCOUNT");
				printf("\n3:RESET PASSWORD");
				printf("\n4:EXIT");
				s3ec:
				printf("\nEnter Choice:");
				scanf("%d",&ch);
				switch(ch)
				{
					case 1:
					{
						clrscr();
						c2c1ep:
						printf("Enter Password:");
						scanf("%d",&epass);
						if(epass==pass)
						{
							clrscr();
							s4:
							printf("1:ADD BALANCE");
							printf("\n2:WITHDRAW");
							printf("\n3:CHECK BALANCE");
							printf("\n4:RESET PASSWORD");
							printf("\n5:EXIT");
							s4ec:
							printf("\nEnter Choice:");
							scanf("%d",&ch);
							switch(ch)
							{
								case 1:
								{
									clrscr();
									c2c1c1ep:
									printf("Enter Password:");
									scanf("%d",&epass);
									if(epass==pass)
									{
										clrscr();
										if(sbal==0)
										{
											sfd:
											printf("Enter Amount:");
											scanf("%d",&fd);
											if(fd<5000)
											{
												clrscr();
												printf("First Deposit Must Be Minimum 5000\n");
												goto sfd;
											}
											else
											{
												sbal=sbal+fd;
												clrscr();
												printf("Balance Added Successfully...\n");
											}
										}
										else
										{
											printf("Enter Amount:");
											scanf("%d",&add);
											sbal=sbal+add;
											clrscr();
											printf("Balance Added Successfully...\n");
										}
									}
									else
									{
										clrscr();
										printf("Wrong Password..!!\n");
										goto c2c1c1ep;
									}
									goto s4;
									break;
								}
								case 2:
								{
									clrscr();
									c2c1c2ep:
									printf("Enter Password:");
									scanf("%d",&epass);
									if(epass==pass)
									{
										clrscr();
										c2c1c2ea:
										printf("Enter Amount:");
										scanf("%d",&wid);
										if(sbal-wid>=1000)
										{
											clrscr();
											sbal=sbal-wid;
											printf("Withdrawal Successfull...\n");
										}
										else
										{
											clrscr();
											printf("Insufficient Funds..!!\n");
											goto c2c1c2ea;
										}
									}
									else
									{
										clrscr();
										printf("Wrong Password..!!\n");
										goto c2c1c2ep;
									}
									goto s4;
									break;
								}
								case 3:
								{
									clrscr();
									c2c1c3ep:
									printf("Enter Password:");
									scanf("%d",&epass);
									if(epass==pass)
									{
										clrscr();
										printf("Your Current Balance Is %d\n",sbal);
									}
									else
									{
										clrscr();
										printf("Wrong Password..!!\n");
										goto c2c1c3ep;
									}
									goto s4;
									break;
								}
								case 4:
								{
									clrscr();
									c2c1c4ep:
									printf("Enter Current Password:");
									scanf("%d",&epass);
									if(epass==pass)
									{
										do
										{
											clrscr();
											printf("Enter New Password:");
											scanf("%d",&pass);
											temp=pass;
											cnt=0;
											r=1;
											while(r!=0)
											{
												if(temp%10!=0)
												{
													r=temp%10;
													cnt++;
													temp=temp/10;
												}
												else
												{
													r=0;
												}
											}
										}while(cnt<4);
										clrscr();
										printf("Password Reseted Successfully...\n");
									}
									else
									{
										clrscr();
										printf("Wrong Password..!!\n");
										goto c2c1c4ep;
									}
									goto s4;
									break;
								}
								case 5:
								{
									break;
								}
								default:
								{
									clrscr();
									printf("Invalid Choice..!!\n");
									goto s4ec;
								}
							}
						}
						else
						{
						    clrscr();
						    printf("Wrong Password..!!\n");
						    goto c2c1ep;
						}
						break;
					}
					case 2:
					{
						clrscr();
						c2c2ep:
						printf("Enter  Password:");
						scanf("%d",&epass);
						if(epass==pass)
						{
							clrscr();
							s5:
							printf("1:ADD BALANCE");
							printf("\n2:WITHDRAW");
							printf("\n3:CHECK BALANCE");
							printf("\n4:RESEST PASSWORD");
							printf("\n5:EXIT");
							s5ec:
							printf("\nEnter Choice:");
							scanf("%d",&ch);
							switch(ch)
							{
								case 1:
								{
									clrscr();
									c2c2c1ep:
									printf("Enter Password:");
									scanf("%d",&epass);
									if(epass==pass)
									{
										if(cbal==0)
										{
											clrscr();
											c2c2c1fd:
											printf("Enter Amount:");
											scanf("%d",&fd);
											if(fd>=10000)
											{
												clrscr();
												cbal=cbal+fd;
												printf("Balance Added Successfully...\n");
											}
											else
											{
												clrscr();
												printf("First Deposit Must Be Minimum 10000\n");
												goto c2c2c1fd;
											}
										}
										else
										{
											clrscr();
											printf("Enter Amount:");
											scanf("%d",&add);
											cbal=cbal+add;
											clrscr();
											printf("Balance Added Successfully...\n");
										}
									}
									else
									{
										clrscr();
										printf("Wrong Password..!!\n");
										goto c2c2c1ep;
									}
									goto s5;
									break;
								}
								case 2:
								{
									clrscr();
									c2c2c2ep:
									printf("Enter Password:");
									scanf("%d",&epass);
									if(epass==pass)
									{
										clrscr();
										c2c2c2ea:
										printf("Enter Amount:");
										scanf("%d",&wid);
										if(cbal-wid>=0)
										{
											clrscr();
											cbal=cbal-wid;
											printf("Withdrawl Successfull...\n");
										}
										else
										{
											clrscr();
											printf("INSUFICIENT FUNDS..!!\n");
											goto c2c2c2ea;
										}
									}
									else
									{
										clrscr();
										printf("Wrong Password..!!\n");
										goto c2c2c2ep;
									}
									goto s5;
									break;
								}
								case 3:
								{
									clrscr();
									c2c2c3ep:
									printf("Enter Password:");
									scanf("%d",&epass);
									if(epass==pass)
									{
										clrscr();
										printf("Your Current Balance Is %d\n",cbal);
									}
									else
									{
										clrscr();
										printf("Wrong Password..!!\n");
										goto c2c2c3ep;
									}
									goto s5;
									break;
								}
								case 4:
								{
									clrscr();
									c2c2c4ep:
									printf("Enter Current Password:");
									scanf("%d",&epass);
									if(epass==pass)
									{
										do
										{
											clrscr();
											printf("Enter New Password:");
											scanf("%d",&pass);
											temp=pass;
											cnt=0;
											r=1;
											while(r!=0)
											{
												if(temp%10!=0)
												{
													r=temp%10;
													cnt++;
													temp=temp/10;
												}
												else
												{
													r=0;
												}
											}
										}while(cnt<4);
										clrscr();
										printf("Password Reseted Successfully...\n");
									}
									else
									{
										clrscr();
										printf("Wrong Password..!!\n");
										goto c2c2c4ep;
									}
									goto s5;
									break;
								}
								case 5:
								{
									break;
								}
								default:
								{
									printf("\nInvalid Choice..!!");
									goto s5ec;
								}
							}
						}
						else
						{
							clrscr();
							printf("Wrong Password..!!\n");
							goto c2c2ep;
						}
						break;
					}
					case 3:
					{
						clrscr();
						c2c4ep:
						printf("Enter Current Password:");
						scanf("%d",&epass);
						if(epass==pass)
						{
							do
							{
								clrscr();
								printf("Enter New Password:");
								scanf("%d",&pass);
								temp=pass;
								cnt=0;
								r=1;
								while(r!=0)
								{
									if(temp%10!=0)
									{
										r=temp%10;
										cnt++;
										temp=temp/10;
									}
									else
									{
										r=0;
									}
								}
							}while(cnt<4);
							clrscr();
							printf("Password Reseted Successfully...\n");
						}
						else
						{
							clrscr();
							printf("Wrong Password..!!\n");
							goto c2c4ep;
						}
						goto s3;
						break;
					}
					case 4:
					{
						break;
					}
					default:
					{
						printf("\nInvalid Choice");
						goto s3ec;
					}
				}
			}
			else
			{
				clrscr();
				printf("Wrong Password..!!\n");
				goto c2ep;
			}
			break;
		}
		case 3:
		{
			clrscr();
			c4ep:
			printf("Enter Current Password:");
			scanf("%d",&epass);
			if(epass==pass)
			{
				do
				{
					clrscr();
					printf("Enter New Password:");
					scanf("%d",&pass);
					temp=pass;
					cnt=0;
					r=1;
					while(r!=0)
					{
						if(temp%10!=0)
						{
							r=temp%10;
							cnt++;
							temp=temp/10;
						}
						else
						{
							r=0;
						}
					}
				}while(cnt<4);
				clrscr();
				printf("Password Reseted Successfully...\n");
			}
			else
			{
				clrscr();
				printf("Wrong Password..!!\n");
				goto c4ep;
			}
			goto s1;
			break;
		}
		case 4:
		{
			break;
		}
		default:
		{
			printf("\nINVALID CHOICE..!!");
			goto ec;
		}
	}
	getch();
}