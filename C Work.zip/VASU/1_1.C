#include<stdio.h>
#include<conio.h>
void main()
{
	clrscr();
	printf("\t\tBIODATA");
	printf("\n\tName:\t\tVasu");
	printf("\n\tGender:\t\tMale");
	printf("\n\tAge:\t\t18");
	printf("\n\tDate Of Birth:\t17/09/2003");
	printf("\n\tAddress:\tB-98,Trikam Nagar-1");
	printf("\n\tHobbies:\tReading,Gaming,Traveling");
	getch();
}
