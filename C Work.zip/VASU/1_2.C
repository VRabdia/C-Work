#include<stdio.h>
#include<conio.h>
void main()
{
	clrscr();
	printf("No.\tName\tS1\tS2\tS3\tS4\tS5\tTotal\n\n");
	printf("1\tabc\t68\t86\t79\t59\t68\t586\n");
	printf("2\tpqr\t78\t76\t86\t95\t69\t869\n");
	printf("3\txyz\t60\t74\t85\t86\t57\t760\n");
	getch();
}