#include<stdio.h>
#include<stdio.h>
void main()
{
	int i;
	float empno,basic,mob,da,hra,others,pf,insu,it,etotal,dtotal,gsalary,nsalary;
	clrscr();
	//EMPNO
	a:
	printf("Enter EMPNO:");
	scanf("%f",&empno);
	if(empno>100 && empno<200)
	{
		b:
		printf("Enter Basic Salary:");
		scanf("%f",&basic);
		if(basic>5000 && basic<30000)
		{
		}
		else
		{
			goto b;
		}
	}
	else
	{
		goto a;
	}
	//MOB
	if(basic<10000)
	{
		mob=(basic*5)/100;
	}
	else if(basic>=10000 && basic<15000)
	{
		mob=(basic*10)/100;
	}
	else
	{
		mob=(basic*12)/100;
	}
	//DA
	if(basic<10000)
	{
		da=(basic*8)/100;
	}
	else if (basic>=10000 && basic<15000)
	{
		da=(basic*10)/100;
	}
	else
	{
		da=(basic*15)/100;
	}
	//HRA
	if(basic<8000)
	{
		hra=(basic*5)/100;
	}
	else if(basic>=8000 && basic<20000)
	{
		hra=(basic*10)/100;
	}
	else
	{
		hra=(basic*12)/100;
	}
	//OTHERS
	if(basic<15000)
	{
		others=(basic*2)/100;
	}
	else if(basic>=15000 && basic<25000)
	{
		others=(basic*3)/100;
	}
	else
	{
		others=(basic*5)/100;
	}
	//TOTAL EARNINGS
	etotal=mob+da+hra+others;
	//GROSS SALARY
	gsalary=basic+etotal;
	//PF
	if(gsalary<8000)
	{
		pf=(gsalary*5)/100;
	}
	else if(gsalary>=8000 && gsalary<15000)
	{
		pf=(gsalary*7)/100;
	}
	else
	{
		pf=(gsalary*10)/100;
	}
	//INSU
	if(gsalary<5000)
	{
		insu=(gsalary*2)/100;
	}
	else if(gsalary>=5000 && gsalary<15000)
	{
		insu=(gsalary*4)/100;
	}
	else
	{
		insu=(gsalary*5)/100;
	}
	//IT
	if(gsalary<8000)
	{
		it=(gsalary*1)/100;
	}
	else if(gsalary>=8000 && gsalary<15000)
	{
		it=(gsalary*2)/100;
	}
	else
	{
		it=(gsalary*3)/100;
	}
	//TOTAL DEDUCTIONS
	dtotal=pf+insu+it;
	//NET SALARY
	nsalary=gsalary-dtotal;
	//OUTPUT
	clrscr();
	for(i=1;i<=80;i++)
	{
		printf("-");
	}
	for(i=1;i<=28;i++)
	{
		printf(" ");
	}
	printf("EMPLOYEE SALARY DETAILS");
	printf("\n");
	for(i=1;i<=80;i++)
	{
		printf("-");
	}
	printf("EMPNO:%.0f",empno);
	printf("\nBASIC:%.0f",basic);
	printf("\n");
	for(i=1;i<=80;i++)
	{
		printf("-");
	}
	printf("EARNINGS");
	printf("\t\t\tDEDUCTIONS");
	printf("\n");
	for(i=1;i<=80;i++)
	{
		printf("-");
	}
	printf("MOB\t= %.2f",mob);
	printf("\t\tPF\t= %.2f",pf);
	printf("\n");
	printf("DA\t= %.2f",da);
	printf("\t\tINSU\t= %.2f",insu);
	printf("\n");
	printf("HRA\t= %.2f",hra);
	printf("\t\tIT\t= %.2f",it);
	printf("\n");
	printf("OTHERS\t= %.2f",others);
	printf("\n");
	for(i=1;i<=80;i++)
	{
		printf("-");
	}
	printf("TOTAL\t= %.2f",etotal);
	printf("\t\tTOTAL\t= %.2f",dtotal);
	printf("\n");
	for(i=1;i<=80;i++)
	{
		printf("-");
	}
	printf("GROSS SALARY = %.2f",gsalary);
	printf("\t\t\tNET SALARY = %.2f",nsalary);
	printf("\n");
	printf("\n");
	for(i=1;i<=37;i++)
	{
		printf("=");
	}
	printf(" END ");
	for(i=1;i<=38;i++)
	{
		printf("=");
	}
	getch();
}