#include<stdio.h>
#include<conio.h>
void main()
{
	int a[100],i,n,temp,k;
	clrscr();
	printf("Enter Size Of Data:");
	scanf("%d",&k);
	for(i=0;i<k;i++)
	{
		printf("A[%d] = ",i);
		scanf("%d",&a[i]);
	}
	for(i=0;i<k;i++)
	{
		printf("\nA[%d] = %d",i,a[i]);
	}
	printf("\nOn Which Position Would You like To Insert Data:");
	scanf("%d",&temp);
	n=k+1;
	for(i=0;i<n;i++)
	{
		if(i==temp)
		{
			for(i=n;i>temp;i--)
			{
				a[i]=a[i-1];
			}
		}
	}
	printf("\nEnter Data:");
	scanf("%d",&a[temp]);
	printf("\nNew Data");
	for(i=0;i<n;i++)
	{
		printf("\nA[%d] = %d",i,a[i]);
	}
	getch();
}