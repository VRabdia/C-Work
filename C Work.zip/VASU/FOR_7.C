#include<stdio.h>
#include<conio.h>
void main()
{
	int a,sum;
	clrscr();
	for(a=1,sum=0;a<=10;a++)
	{
		if(a%2==0)
		{
		}
		else
		{
			printf("\n%d",a);
			sum=sum+a;
		}
	}
	printf("\nSum=%d",sum);
	getch();
}