#include<stdio.h>
#include<conio.h>
void main()
{
	int r;
	float pi=3.14,cir,area;
	clrscr();
	printf("Enter the Radius of the Circle: ");
	scanf("%d",&r);
	area=pi*r*r;
	printf("\nThe Area of the Circle is: %f",area);
	cir=2*pi*r;
	printf("\nThe Circumferenece of the Circle is: %f",cir);


	getch();
}