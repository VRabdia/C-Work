#include<stdio.h>
#include<stdio.h>
void main()
{
	int n,r,cube,sum=0,a;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	a=n;
	do
	{
		r=n%10;
		cube=r*r*r;
		sum=sum+cube;
		n=n/10;
	}while(n>0);
	if(a==sum)
	{
		printf("\n%d is a armstrong number",a);
	}
	else
	{
		printf("\n%d is not a armstrong number",a);
	}
	getch();
}