#include<stdio.h>
#include<conio.h>
void main()
{
	char s[100],i,n=0;
	clrscr();
	printf("Enter String:");
	gets(s);
	printf("\n\n");
	for(i=0;s[i]!=NULL;i++)
	{
		n++;
	}
	for(i=n;i>=0;i--)
	{
		printf("%c",s[i]);
	}
	getch();
}