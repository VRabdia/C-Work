#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,even=0,odd=0;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);
	if(a<b)
	{
		while(a<=b)
		{
			if(a%2==0)
			{
				even=even+a;
				a++;
			}
			else
			{
				odd=odd+a;
				a++;
			}
		}
	}
	else
	{
		while(a>=b)
		{
			if(a%2==0)
			{
				even=even+a;
				a--;
			}
			else
			{
				odd=odd+a;
				a--;
			}
		}
	}
	printf("\nEven Sum=%d",even);
	printf("\nOdd Sum=%d",odd);

	getch();
}