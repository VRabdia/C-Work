#include<stdio.h>
#include<conio.h>
void main()
{
	int n,r,cube,temp,sum;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	temp=n;
	for(r=0,cube=0,sum=0;n>0;)
	{
		r=n%10;
		cube=r*r*r;
		sum=sum+cube;
		n=n/10;
	}
	if(temp==sum)
	{
		printf("\n%d is an armstrong number.",temp);
	}
	else
	{
		printf("\n%d is not an armstrong number.",temp);
	}
	getch();
}