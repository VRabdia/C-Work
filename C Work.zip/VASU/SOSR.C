#include<stdio.h>
#include<conio.h>
struct var
{
	char n[100];
	int i,s1,s2,s3,s4,s5,total,pr;
};
void main()
{
	struct var f;
	clrscr();
	printf("Enter Name:");
	gets(f.n);
	printf("Enter Subject 1 Marks:");
	scanf("%d",&f.s1);
	printf("Enter Subject 2 Marks:");
	scanf("%d",&f.s2);
	printf("Enter Subject 3 Marks:");
	scanf("%d",&f.s3);
	printf("Enter Subject 4 Marks:");
	scanf("%d",&f.s4);
	printf("Enter Subject 5 Marks:");
	scanf("%d",&f.s5);
	f.total=f.s1+f.s2+f.s3+f.s4+f.s5;
	f.pr=f.total/5;
	clrscr();
	printf("Name:");
	for(f.i=0;f.n[f.i]!=0;f.i++)
	{
		printf("%c",f.n[f.i]);
	}
	printf("\n\n\nSubject 1\tSubject 2\tSubject 3\tSubject 4\tSubject 5");
	printf("\n%d\t\t%d\t\t%d\t\t%d\t\t%d",f.s1,f.s2,f.s3,f.s4,f.s5);
	printf("\n\nTotal\t\t= %d",f.total);
	printf("\nPercentage\t= %d",f.pr);
	getch();
}