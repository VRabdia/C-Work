#include<stdio.h>
#include<conio.h>
void main()
{
	int a,i=1,fact=1;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	while(i<=a)
	{
		fact=fact*i;
		i++;
	}
	printf("\n%d!=%d",a,fact);
	getch();
}