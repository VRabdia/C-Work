#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,k,l,m;
	clrscr();
	for(i=1,l=2,m=1;i<=9;i++)
	{
		for(k=1;k<=5-i && i<=5;k++)
		{
			printf(" ");
		}
		for(j=1;j<=i && i<=5;j++)
		{
			printf("*");
		}
		for(k=1;k<=m && i>5;k++)
		{
			printf(" ");
		}
		for(j=i-l;j>=1 && i>5;j--)
		{
			printf("*");
		}
		if(i>5)
		{
			l=l+2;
			m++;
		}
		printf("\n");
	}
	getch();
}