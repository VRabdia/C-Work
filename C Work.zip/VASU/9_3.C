#include<stdio.h>
#include<conio.h>
void main()
{
	int n,i=0,sum=0;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	while(i<=n)
	{
		sum=sum+i;
		i++;
	}
	printf("\nSum:%d",sum);

	getch();
}