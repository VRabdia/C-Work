#include<stdio.h>
#include<conio.h>
void main()
{
	int a;
	clrscr();
	for(a=1;a<=10;a++)
	{
		printf("\n%d",a);
	}
	getch();
}