#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("\nEnter b:");
	scanf("%d",&b);

	if(a<b)
	{
		while(a<=b)
		{
			if(a%2==0)
			{
				a++;
			}
			else
			{
				printf("\n%d",a);
				a++;
			}
		}
	}
	else
	{
		while(a>=b)
		{
			if(a%2==0)
			{
				printf("\n%d",a);
				a--;
			}
			else
			{
				a--;
			}
		}
	}
	getch();
}