#include<stdio.h>
#include<conio.h>
void sum()
{
	int a[100][100],b[100][100],sum[100][100],i,j,r,c;
	printf("Enter Number Of Rows:");
	scanf("%d",&r);
	printf("Enter Number Of Columns:");
	scanf("%d",&c);
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			printf("A[%d][%d] = ",i,j);
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			printf("B[%d][%d] = ",i,j);
			scanf("%d",&b[i][j]);
		}
	}
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			sum[i][j]=a[i][j]+b[i][j];
		}
	}
	printf("\n\n\n");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			printf("\t%d",sum[i][j]);
		}
		printf("\n");
	}
}
void main()
{
	clrscr();
	sum();
	getch();
}