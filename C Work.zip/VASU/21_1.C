#include<stdio.h>
#include<conio.h>
struct var
{
	int n;
	float f;
	char c;
};
void main()
{
	struct var a;
	clrscr();
	printf("Enter int:");
	scanf("%d",&a.n);
	printf("Enter float:");
	scanf("%f",&a.f);
	flushall();
	printf("Enter char:");
	scanf("%c",&a.c);
	printf("\nint\t= %d",a.n);
	printf("\nfloat\t= %f",a.f);
	printf("\nchar\t= %c",a.c);
	getch();
}