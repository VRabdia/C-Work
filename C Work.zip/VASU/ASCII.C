#include<stdio.h>
#include<conio.h>
void main()
{
	char i,a=1,ent;
	clrscr();
	loop:
	clrscr();
	for(i=1;i<=10 && a<127;i++)
	{
		printf("\n%c",a);
		a++;
	}
	scanf("%c",&ent);
	if(ent==10)
	{
		goto loop;
	}
	getch();
}