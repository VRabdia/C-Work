#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,k,l,m;
	clrscr();
	for(i=1,l=2,m=3;i<=9;i++)
	{
		for(k=1;k<=5-i && i<=5;k++)
		{
			printf(" ");
		}
		for(j=1;j<=i && i<=5;j++)
		{
			printf("%d",j);
		}
		for(j=i-1;j>=1 && i<=5;j--)
		{
			printf("%d",j);
		}
		for(k=i-5;k>=1 && i>5;k--)
		{
			printf(" ");
		}
		for(j=1;j<=i-l && i>5;j++)
		{
			printf("%d",j);
		}
		for(j=m;j>=1 && i>5;j--)
		{
			printf("%d",j);
		}
		if(i>5)
		{
			l=l+2;
			m--;
		}
		printf("\n");
	}
	getch();
}