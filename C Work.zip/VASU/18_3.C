#include<stdio.h>
#include<conio.h>
void main()
{
	char a;
	clrscr();
	printf("Enter ASCII Code:");
	scanf("%d",&a);
	printf("\n%c",a);
	getch();
}