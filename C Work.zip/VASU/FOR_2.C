#include<stdio.h>
#include<conio.h>
void main()
{
	int a;
	clrscr();
	for(a=10;a>=1;a--)
	{
		printf("\n%d",a);
	}
	getch();
}