#include<stdio.h>
#include<conio.h>
void main()
{
	int n,i=1,cnt=0;
	clrscr();
	printf("Enter n:");
	scanf("%d",&n);
	do
	{
		if(n%i==0)
		{
			cnt++;
			i++;
		}
		else
		{
			i++;
		}
	}while(i<=n);

	if(cnt==2)
	{
		printf("\n%d is a prime number.",n);
	}
	else
	{
		printf("\n%d is not a prime number.",n);
	}
	getch();
}