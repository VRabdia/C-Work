#include"maze.hpp"
#include<iostream>

using std::cout; using std::cin; using std::endl;

void clearWalls(RoomPair rp[]) {
	for (int i = 0; i < numWalls; i++) {
		rp[i].one.x = -1;
		rp[i].one.y = '*';
		rp[i].two.x = -1;
		rp[i].two.y = '*';
	}
}

bool goodDirection(const Room& rm, const char dr) {
	bool result;
	if (dr == 'l' && rm.x == 1)
	{
		result = false;
	}
	else if (dr == 'r' && rm.x == mazeSize)
	{
		result = false;
	}
	else if (dr == 'u' && rm.y == 'a')
	{
		result = false;
	}
	else if (dr == 'd' && rm.y == 'a' + mazeSize - 1)
	{
		result = false;
	}
	else
	{
		result = true;
	}
	return result;
}

Room createAdjacent(const Room& rm, const char dr) {
	Room newRoom = rm;
	if (dr == 'l')
	{
		newRoom.x = rm.x - 1;
	}
	else if (dr == 'r')
	{
		newRoom.x = rm.x + 1;
	}
	else if (dr == 'u')
	{
		newRoom.y = rm.y - 1;
	}
	else if (dr == 'd')
	{
		newRoom.y = rm.y + 1;
	}
	return newRoom;
}

void printRoom(const Room& myRoom) {
	cout << myRoom.x << myRoom.y;
}

const Room nextMove(const Room& myRoom) {
	cout << "Enter new adjacent room (u)p, (d)own, (l)eft, (r)ight, or (q)uit: ";
	char dr;
	cin >> dr;
	Room newMoveRoom = myRoom;
	if (dr == 'l')
	{
		newMoveRoom.x = myRoom.x - 1;
	}
	else if (dr == 'r')
	{
		newMoveRoom.x = myRoom.x + 1;
	}
	else if (dr == 'u')
	{
		newMoveRoom.y = myRoom.y - 1;
	}
	else if (dr == 'd')
	{
		newMoveRoom.y = myRoom.y + 1;
	}
	else if (dr == 'q')
	{
		newMoveRoom.x = -1;
		newMoveRoom.y = '*';
	}
	return newMoveRoom;
}

const Room pickAdjacent(const Room& myRoom) {
	Room randomRoom;
	char dr = '0';
	while (dr == '0')
	{
		int randomDr = rand() % 4;
		switch (randomDr)
		{
		case 0:
			dr = 'u';
			break;
		case 1:
			dr = 'd';
			break;
		case 2:
			dr = 'l';
			break;
		case 3:
			dr = 'r';
			break;
		default:
			break;
		}

		if (goodDirection(myRoom, dr))
		{
			randomRoom = createAdjacent(myRoom, dr);
		}
		else
		{
			dr = '0';
		}
	}
	return randomRoom;
}

bool matchRoom(const Room& randomRoom, const Room& newMoveRoom) {
	if (randomRoom.x == newMoveRoom.x && randomRoom.y == newMoveRoom.y)
	{
		return true;
	}
	else
	{
		return false;
	}
}

const RoomPair pickPair() {
	int x = rand() % mazeSize + 1;
	char y;
	switch (x)
	{
	case 1:
		y = 'a';
		break;
	case 2:
		y = 'a' + x - 1;
		break;
	case 3:
		y = 'a' + x - 2;
		break;
	case 4:
		y = 'a' + x - 3;
		break;
	default:
		y = 'a';
		break;
	}

	Room myRoom;
	myRoom.x = x;
	myRoom.y = y;

	Room adjRoom = pickAdjacent(myRoom);

	RoomPair rp;
	rp.one = myRoom;
	rp.two = adjRoom;

	return rp;
}

bool matchPair(const RoomPair& rp1, const RoomPair& rp2) {
	if (matchRoom(rp1.one, rp2.one) && matchRoom(rp1.two, rp2.two))
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool checkMaze(const RoomPair roompair[], const RoomPair& rp) {

	Room myRoom = rp.one;
	Room nextRoom = rp.two;
	char dr;
	if (nextRoom.x == myRoom.x - 1) {
		dr = 'l';
	}
	else if (nextRoom.x == myRoom.x + 1) {
		dr = 'r';
	}
	else if (nextRoom.y == myRoom.y - 1) {
		dr = 'u';
	}
	else if (nextRoom.y == myRoom.y + 1) {
		dr = 'd';
	}
	else
	{
		dr = 'q';
	}

	if (goodDirection(myRoom, dr)) {
		for (int i = 0; i < numWalls; i++)
		{
			if (matchPair(roompair[i], rp))
			{
				return true;
			}
			else if (i == numWalls - 1)
			{
				return false;
			}
		}
	}
	else
	{
		return true;
	}
}

void printPair(const RoomPair& rp) {
	printRoom(rp.one);
	cout << "|";
	printRoom(rp.two);
	cout << "  ";
}

void printMaze(const RoomPair rp[]) {
	for (int i = 0; i < numWalls; i++) {
		printPair(rp[i]);
	}
}

void build(RoomPair rp[]) {
	for (int i = 0; i < numWalls; i++) {
		RoomPair wall;
		wall.one.x = rand() % mazeSize + 1;
		wall.one.y = 'a' + rand() % mazeSize;
		wall.two = pickAdjacent(wall.one);
		rp[i] = wall;
	}
}