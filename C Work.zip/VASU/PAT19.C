#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,k;
	clrscr();
	for(i=1;i<=10;i++)
	{
		if(i%2==0)
		{
		}
		else
		{
			for(k=1;k<i;k++)
			{
				if(k%2==0)
				{
				}
				else
				{
					printf(" ");
				}
			}
			for(j=i;j<=10;j++)
			{
				if(j%2==0)
				{
				}
				else
				{
					printf("%d",j);
				}
			}
			printf("\n");
		}
	}
	getch();
}