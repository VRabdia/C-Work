#include<stdio.h>
#include<conio.h>
void tri(int b,int h)
{
	int area;
	area=(b*h)/2;
	printf("\nArea = %d",area);
}
void cir(int r)
{
	float area,pi=3.14;
	area=pi*r*r;
	printf("\nArea = %.2f",area);
}
void rec(int l,int b)
{
	int area;
	area=l*b;
	printf("\nArea = %d",area);
}
void squ(int l)
{
	int area;
	area=l*l;
	printf("\nArea = %d",area);
}
void main()
{
	int ch,r,b,h,l;
	clrscr();
	sc:
	printf("1:Area Of Triangle");
	printf("\n2:Area Of Circle");
	printf("\n3:Area Of Rectangle");
	printf("\n4:Area Of Square");
	printf("\n\nEnter Choice:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:
		{
			clrscr();
			printf("Enter Base:");
			scanf("%d",&b);
			printf("Enter Height:");
			scanf("%d",&h);
			tri(b,h);
			break;
		}
		case 2:
		{
			clrscr();
			printf("Enter Radius:");
			scanf("%d",&r);
			cir(r);
			break;
		}
		case 3:
		{
			clrscr();
			printf("Enter Length:");
			scanf("%d",&l);
			printf("Enter Broadness:");
			scanf("%d",&b);
			rec(l,b);
			break;
		}
		case 4:
		{
			clrscr();
			printf("Enter Length:");
			scanf("%d",&l);
			squ(l);
			break;
		}
		default:
		{
			clrscr();
			printf("INVALID CHOICE..!!\n\n");
			goto sc;
		}
	}
	getch();
}