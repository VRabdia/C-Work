#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c;
	clrscr();
	printf("Enter a: ");
	scanf("%d",&a);
	printf("\nEnter b: ");
	scanf("%d",&b);
	printf("\nEnter c: ");
	scanf("%d",&c);

	if(a==b)
	{
		if(a==c)
		{
			printf("a,b,c are same");
		}
		else
		{
			if(a>c)
			{
				printf("a,b are same c is min");
			}
			else
			{
				printf("a,b are same c is max");
			}
		}
	}
	else
	{
		if(a==c)
		{
			if(b>c)
			{
				printf("a,c are same b is max");
			}
			else
			{
				printf("a,c are same b is min");
			}
		}
		else
		{
			if(b==c)
			{
				if(a>c)
				{
					printf("b,c are same a is max");
				}
				else
				{
					printf("b,c are same a is min");
				}
			}
			else
			{
				if(a>b)
				{
					if(a>c)
					{
						printf("a,b,c is diiferent a is max");
					}
					else
					{
						printf("a,b,c is different c is max");
					}
				}
				else
				{
					if(b>c)
					{
						printf("a,b,c is different b is max");
					}
					else
					{
						printf("a,b,c is different c is max");
					}
				}
			}
		}
	}

	getch();
}
