#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c,d,e;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("\nEnter b:");
	scanf("%d",&b);
	printf("\nEnter c:");
	scanf("%d",&c);
	printf("\nEnter d:");
	scanf("%d",&d);
	printf("\nEnter e:");
	scanf("%d",&e);
	if(a>b && a>c && a>d && a>e)
	{
		printf("a is max");
	}
	else if(b>c && b>d && b>e)
	{
		printf("b is max");
	}
	else if(c>d && c>e)
	{
		printf("c is max");
	}
	else if(d>e)
	{
		printf("d is max");
	}
	else
	{
		printf("e is max");
	}
	getch();
}