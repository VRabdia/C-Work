#include<stdio.h>
#include<conio.h>
void main()
{
	int cnt=0,cpass,npass;
	clrscr();

	//CREATE PASSWORD
	do
	{
		printf("Create Password:");
		scanf("%d",&cpass);
		if(cpass>999)
		{
			cnt=3;
		}
		else
		{
			if(cnt<2)
			{
				cnt++;
			}
			else
			{
				printf("\nPlease Try Again Later...");
				cnt=3;
			}
		}
	}while(cnt<3);

	//CNT
	if(cpass>999)
	{
		cnt=0;
		clrscr();
	}
	else
	{
	}

	//ENTER PASSWORD
	while(cnt<3)
	{
		printf("Enter Password:");
		scanf("%d",&npass);
		if(cpass==npass)
		{
			printf("\nWelcome");
			cnt=4;
		}
		else
		{
			if(cnt<2)
			{
				cnt++;
			}
			else
			{
				printf("Please Try Again Later...");
				cnt=4;
			}
		}
	}
	getch();
}