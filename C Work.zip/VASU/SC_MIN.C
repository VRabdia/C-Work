#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b;
	clrscr();
	printf("Enter a:");
	scanf("%d",&a);
	printf("Enter b:");
	scanf("%d",&b);
	switch(a<b)
	{
		case 1:
		printf("a is min");
		break;
		default:
		printf("b is min");
	}
	getch();
}