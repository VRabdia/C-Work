#include "sudoku.hpp"

bool match(vector<int> vec, int num)
{
	for (size_t i = 0; i < vec.size(); ++i)
	{
		if (vec[i] == num)
		{
			return true;
		}
	}
	return false;
}

bool xorMatch(bool a, bool b, bool c) {
	return (a && b && c);
}